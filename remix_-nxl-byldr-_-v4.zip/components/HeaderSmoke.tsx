import React, { useEffect, useRef } from 'react';
import webGLFluidCustom from 'webgl-fluid-custom';

interface HeaderSmokeProps {
  active?: boolean;
  intensified?: boolean;
}

export const HeaderSmoke: React.FC<HeaderSmokeProps> = ({ active = true, intensified = false }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (canvasRef.current) {
      const fluid = webGLFluidCustom(canvasRef.current, {
        TRIGGER: 'hover',
        SIM_RESOLUTION: 128, // Lower resolution for softer, more diffused look
        DENSITY_DISSIPATION: 0.97, // Faster dissipation for "Mist" effect
        VELOCITY_DISSIPATION: 0.98, // More damping to prevent clumping
        PRESSURE: 0.8,
        CURL: intensified ? 50 : 30, // Reduced curl for gentler swirls
        SPLAT_RADIUS: intensified ? 0.6 : 0.4, // Much larger radius for "Mist" look
        SHADING: true,
        COLORFUL: false,
        PAUSED: false,
        COLOR_PALETTE: ['#FF3B5C', '#7000FF'], // Two-Tone: Watermelon Red, Sunset Purple
        BLOOM: true,
        BLOOM_ITERATIONS: 4, // Fewer iterations for softer glow
        BLOOM_INTENSITY: intensified ? 1.2 : 0.8, // Subtle glow
        BLOOM_THRESHOLD: 0.4,
        SUNRAYS: false,
        BACK_COLOR: { r: 0, g: 0, b: 0 },
        TRANSPARENT: true,
        GUI: false,
      });

      // Manual interaction for "Force" and "Vorticity"
      let lastX = 0;
      let lastY = 0;

      const handleMove = (e: MouseEvent | TouchEvent) => {
        if (!active || !fluid || typeof (fluid as any).splat !== 'function') return;

        const rect = canvasRef.current?.getBoundingClientRect();
        if (!rect) return;

        let clientX, clientY;
        if ('touches' in e) {
          clientX = e.touches[0].clientX;
          clientY = e.touches[0].clientY;
        } else {
          clientX = e.clientX;
          clientY = e.clientY;
        }

        // Only react if within or near the active area
        if (clientY > rect.bottom + 50) return;

        const x = (clientX - rect.left) / rect.width;
        const y = (clientY - rect.top) / rect.height;

        // Calculate velocity for "Force" - Significantly reduced for "Glow" effect
        const forceMultiplier = intensified ? 3000 : 1500;
        const dx = (x - lastX) * forceMultiplier; 
        const dy = (y - lastY) * forceMultiplier;

        try {
          // @ts-ignore
          fluid.splat(x, y, dx, dy);
        } catch (err) {
          // Ignore
        }

        lastX = x;
        lastY = y;
      };

      window.addEventListener('mousemove', handleMove);
      window.addEventListener('touchmove', handleMove);

      return () => {
        window.removeEventListener('mousemove', handleMove);
        window.removeEventListener('touchmove', handleMove);
      };
    }
  }, [active, intensified]);

  return (
    <div className="absolute inset-0 z-0 overflow-hidden">
      <canvas
        ref={canvasRef}
        className="w-full h-full opacity-100"
        style={{ transform: 'scale(1.1)' }}
      />
    </div>
  );
};
