import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, useScroll, useTransform, useMotionValue, animate } from 'framer-motion';
import { ArrowRight, Twitter, Linkedin, Instagram, Globe, ArrowUpRight, Facebook } from 'lucide-react';
import Button from './Button';
import AiAssistant from './AiAssistant';
import FluidCursor from './FluidCursor';
import { CustomCursor } from './CustomCursor';
import { useLanguage } from '../contexts/LanguageContext';
import Particles, { initParticlesEngine } from "@tsparticles/react";
import { loadSlim } from "@tsparticles/slim";

interface LayoutProps {
  children: React.ReactNode;
  fluidInteractive?: boolean;
}

const Layout: React.FC<LayoutProps> = ({ children, fluidInteractive = true }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [canInteract, setCanInteract] = useState(true);
  const [isIntroDone, setIsIntroDone] = useState(false);
  const [showParticles, setShowParticles] = useState(false);
  const [particlesInit, setParticlesInit] = useState(false);
  const { t, language, setLanguage } = useLanguage();
  const isHome = location.pathname === '/';

  const { scrollY } = useScroll();
  
  // Intro Fade-in logic for Home
  const introMV = useMotionValue(0);
  
  // Particle Visibility: 100% at top, fades to 15% floor at 400px
  // ONLY visible once intro and fade-out are 100% done
  const particleOpacity = useTransform([scrollY, introMV], ([s, i]) => {
    if (!isHome || !showParticles) return 0; 
    
    const scrollBase = s as number;
    const introBase = i as number;
    
    // Hide particles completely until intro is finished and site revealed
    if (introBase < 1) return 0;
    
    // Calculate scroll-based opacity (1.0 -> 0.15 floor)
    let opacity = 1;
    if (scrollBase <= 400) {
      opacity = 1 - (scrollBase / 400) * 0.85;
    } else {
      opacity = 0.15;
    }
    
    return opacity;
  });
  
  useEffect(() => {
    // Force scroll to top on every load/home navigation
    window.scrollTo(0, 0);
    
    if (isHome) {
      setIsIntroDone(false);
      setShowParticles(false);
      introMV.set(0);
      
      // The intro sequence timer: 
      // 3s (Logo Reveal) + 1.5s (Transition to Black)
      const timer = setTimeout(() => {
        animate(introMV, 1, { 
          duration: 2, // Smooth 2s particle reveal duration as requested
          ease: "easeInOut",
          onComplete: () => setShowParticles(true)
        });
        setIsIntroDone(true);
      }, 4500); 
      return () => clearTimeout(timer);
    } else {
      introMV.set(1);
      setIsIntroDone(true);
      setShowParticles(true);
    }
  }, [isHome]); // Removed introMV from deps to avoid re-runs unless path changes

  useEffect(() => {
    const unsubscribe = scrollY.on("change", (latest) => {
      setCanInteract(latest < 400);
    });
    return () => unsubscribe();
  }, [scrollY]);

  useEffect(() => {
    initParticlesEngine(async (engine) => {
      await loadSlim(engine);
    }).then(() => {
      setParticlesInit(true);
    });
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <div className="min-h-screen bg-black text-slate-100 flex flex-col font-sans selection:bg-[#B32D6A]/30 selection:text-pink-100 relative overflow-x-hidden">
      
      {/* WebGL Fluid Simulation Background */}
      {isHome && (
        <motion.div 
          style={{ opacity: introMV }}
          className="fixed inset-0 z-[0] pointer-events-none"
        >
          <FluidCursor interactive={fluidInteractive} />
        </motion.div>
      )}
      <CustomCursor />

      {/* Global Floating Particle Nodes */}
      {isHome && particlesInit && (
        <motion.div 
          style={{ opacity: particleOpacity }}
          className="fixed inset-0 z-[6] pointer-events-none"
        >
          <Particles
            id="tsparticles-global"
            options={{
              fullScreen: { enable: false },
              particles: {
                number: { value: 90, density: { enable: true } }, 
                color: { value: ["#ffffff", "#B32D6A"] }, 
                shape: { type: "circle" },
                opacity: { 
                  value: { min: 0.18, max: 0.5 }, 
                  animation: { enable: true, speed: 0.5, sync: false }
                },
                size: { 
                  value: { min: 1.1, max: 4.4 }, 
                  animation: { enable: true, speed: 2, sync: false }
                },
                links: { 
                  enable: true, 
                  distance: 180, 
                  color: "random", 
                  opacity: 0.2, 
                  width: 1.1, 
                  triangles: { enable: false }
                },
                move: {
                  enable: true,
                  speed: 0.35,
                  direction: "none",
                  random: true,
                  straight: false,
                  outModes: { default: "out" },
                  attract: { enable: true, rotate: { x: 600, y: 1200 } } 
                },
                shadow: {
                  enable: true,
                  color: "#B32D6A", 
                  blur: 5
                }
              },
              interactivity: {
                events: { 
                  onHover: { enable: true, mode: ["grab", "bubble"] },
                  onDiv: { selectors: "#nxl-byldr-logo", enable: true, mode: "repulse", type: "circle" }
                },
                modes: { 
                  grab: { 
                    distance: 250,
                    links: { opacity: 0.4 }
                  },
                  bubble: {
                    distance: 200,
                    size: 6,
                    duration: 0.3,
                    opacity: 0.8
                  },
                  repulse: {
                    distance: 200,
                    duration: 0.4
                  }
                }
              },
              retina_detect: true
            }}
            className="w-full h-full"
          />
        </motion.div>
      )}

      {/* Global Noise Texture */}
      <div className="fixed inset-0 z-[100] pointer-events-none opacity-[0.04] mix-blend-overlay" 
           style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }}>
      </div>

      {/* Navigation */}
      <header 
        style={{ 
          backgroundColor: '#000000',
          zIndex: 9999
        }}
        className="fixed top-0 w-full h-[80px] overflow-hidden"
      >
        <div className="max-w-[1800px] mx-auto px-8 py-4 flex justify-between items-center gap-8 relative z-[10]">
          {/* Left: Language Switcher */}
          <div className="flex items-center">
            <div className="bg-white/5 border border-white/10 rounded-full p-1 flex items-center backdrop-blur-md">
              <button 
                onClick={() => setLanguage('en')}
                style={{ textShadow: '0 0 10px rgba(0,0,0,0.8)' }}
                className={`px-4 py-1.5 rounded-full text-[10px] font-black tracking-widest transition-all ${language === 'en' ? 'bg-white text-black' : 'text-white/40 hover:text-white'}`}
              >
                ENG
              </button>
              <button 
                onClick={() => setLanguage('es')}
                style={{ textShadow: '0 0 10px rgba(0,0,0,0.8)' }}
                className={`px-4 py-1.5 rounded-full text-[10px] font-black tracking-widest transition-all ${language === 'es' ? 'bg-white text-black' : 'text-white/40 hover:text-white'}`}
              >
                ESP
              </button>
            </div>
          </div>

          {/* Center: Logo & Nav */}
          <div className="flex items-center gap-12">
            <Link 
              to="/" 
              onClick={() => {
              window.scrollTo(0, 0);
              if (isHome) {
                introMV.set(0);
                setIsIntroDone(false);
                setShowParticles(false);
                setTimeout(() => {
                  animate(introMV, 1, { duration: 2, ease: 'easeInOut', onComplete: () => setShowParticles(true) });
                  setIsIntroDone(true);
                }, 4500);
              }
            }}
              className="flex items-center gap-3 group drop-shadow-[0_0_15px_rgba(179,45,106,0.4)]"
            >
              <svg viewBox="0 0 144 144" className="w-6 h-6" xmlns="http://www.w3.org/2000/svg">
                <polygon fill="#B32D6A" points="41.66,143.61 0.32,143.61 0.37,0.59" />
                <polygon fill="#B32D6A" points="143.68,0.34 102.39,143.36 143.72,143.36" />
                <polygon fill="#B32D6A" points="71.46,98.11 93.64,36.18 87.29,39.32 95.96,0.57 47.65,0.57 62.18,73.05 67.34,68.55" />
              </svg>
              <div 
                style={{ textShadow: '0 0 10px rgba(0,0,0,0.8)' }}
                className="text-sm font-display tracking-[0.2em] flex items-center transition-colors text-white"
              >
                <span className="font-black">VSUAL</span>
                <span className="font-light">digitalmedia</span>
              </div>
            </Link>
            
            <nav className="hidden md:flex items-center gap-8">
              {[
                { name: t('nav.engine'), path: '/engine' },
                { name: t('nav.results'), path: '/results' },
                { name: t('nav.portal'), path: '/portal' }
              ].map((link) => (
                <Link 
                  key={link.path}
                  to={link.path} 
                  style={{ textShadow: '0 0 10px rgba(0,0,0,0.8)' }}
                  className={`text-[10px] font-display font-bold tracking-[0.2em] transition-colors uppercase relative py-2 drop-shadow-[0_0_10px_rgba(179,45,106,0.3)] ${
                    location.pathname === link.path 
                      ? 'text-white' 
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  {link.name}
                  {location.pathname === link.path && (
                    <motion.div 
                      layoutId="nav-underline"
                      className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#B32D6A]"
                    />
                  )}
                </Link>
              ))}
            </nav>
          </div>

          {/* Right: Action Button */}
          <div className="flex items-center">
            <Link to="/build">
              <button 
                style={{ textShadow: '0 0 10px rgba(0,0,0,0.8)' }}
                className="text-[10px] font-display font-black uppercase tracking-[0.2em] px-6 py-2.5 rounded-full transition-all bg-[#B32D6A] text-white hover:bg-white hover:text-black shadow-lg shadow-[#B32D6A]/20 drop-shadow-[0_0_15px_rgba(179,45,106,0.6)]"
              >
                {t('nav.build')}
              </button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow relative z-[2]">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-black border-t border-white/5 pt-32 pb-12 relative overflow-hidden z-[10]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          {/* Top Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-24">
            {/* Brand & Certs */}
            <div className="lg:col-span-1">
              <Link to="/" className="flex items-center gap-3 group mb-8">
                <svg viewBox="0 0 144 144" className="w-8 h-8" xmlns="http://www.w3.org/2000/svg">
                  <polygon fill="#B32D6A" points="41.66,143.61 0.32,143.61 0.37,0.59" />
                  <polygon fill="#B32D6A" points="143.68,0.34 102.39,143.36 143.72,143.36" />
                  <polygon fill="#B32D6A" points="71.46,98.11 93.64,36.18 87.29,39.32 95.96,0.57 47.65,0.57 62.18,73.05 67.34,68.55" />
                </svg>
                <div className="text-lg font-display tracking-[0.2em] text-white flex items-center">
                  <span className="font-black">VSUAL</span>
                </div>
              </Link>
              <div className="flex gap-4 opacity-40 grayscale hover:grayscale-0 transition-all">
                <div className="w-12 h-12 border border-white/20 rounded flex items-center justify-center text-[8px] font-bold text-center leading-tight">NXL<br/>CERT</div>
                <div className="w-12 h-12 border border-white/20 rounded flex items-center justify-center text-[8px] font-bold text-center leading-tight">KAIZEN<br/>APPV</div>
                <div className="w-12 h-12 border border-white/20 rounded flex items-center justify-center text-[8px] font-bold text-center leading-tight">AI<br/>STRAT</div>
              </div>
            </div>

            {/* Contact */}
            <div>
              <h3 className="text-white font-display font-bold text-sm uppercase mb-8 tracking-widest">{t('footer.contact')}</h3>
              <div className="space-y-6 text-sm text-slate-400">
                <p>
                  <span className="text-white block font-medium mb-1">{t('footer.la_office')}</span>
                  12510 Mc Cann Dr.<br/>
                  Santa Fe Springs, CA 90670
                </p>
                <p>
                  <span className="text-white block font-medium mb-1">{t('footer.oc_office')}</span>
                  Irvine Spectrum Center<br/>
                  Irvine, CA 92618
                </p>
                <a href="https://maps.google.com/?q=12510+Mc+Cann+Dr.+Santa+Fe+Springs+CA+90670" target="_blank" rel="noopener noreferrer" className="text-[#B32D6A] hover:underline block font-medium">{t('footer.directions')}</a>
                <p>
                  <a href="mailto:ops@nxlbyldr.com" className="hover:text-white transition-colors">ops@nxlbyldr.com</a><br/>
                  <a href="tel:+15629440500" className="hover:text-white transition-colors">562.944.0500</a>
                </p>
              </div>
            </div>

            {/* Services */}
            <div>
              <h3 className="text-white font-display font-bold text-sm uppercase mb-8 tracking-widest">{t('footer.services')}</h3>
              <ul className="space-y-4 text-sm text-slate-400">
                <li><Link to="/services" className="hover:text-white transition-colors">Performance Websites</Link></li>
                <li><Link to="/services" className="hover:text-white transition-colors">AI-Driven Marketing</Link></li>
                <li><Link to="/services" className="hover:text-white transition-colors">Brand Infrastructure</Link></li>
                <li><Link to="/services" className="hover:text-white transition-colors">Automated Operations</Link></li>
                <li><Link to="/services" className="hover:text-white transition-colors">Growth Systems</Link></li>
              </ul>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-white font-display font-bold text-sm uppercase mb-8 tracking-widest">{t('footer.quick_links')}</h3>
              <ul className="space-y-4 text-sm text-slate-400">
                <li><Link to="/engine" className="hover:text-white transition-colors">{t('nav.engine')}</Link></li>
                <li><Link to="/results" className="hover:text-white transition-colors">{t('nav.results')}</Link></li>
                <li><Link to="/portal" className="hover:text-white transition-colors">{t('nav.portal')}</Link></li>
                <li><Link to="/build" className="hover:text-white transition-colors">{t('nav.build')}</Link></li>
                <li><Link to="/about" className="hover:text-white transition-colors">{t('nav.about')}</Link></li>
                <li><Link to="/careers" className="hover:text-white transition-colors">Careers</Link></li>
                <li><Link to="/faq" className="hover:text-white transition-colors">{t('nav.faq')}</Link></li>
              </ul>
            </div>

            {/* Sector Spotlight */}
            <div>
              <h3 className="text-white font-display font-bold text-sm uppercase mb-8 tracking-widest">{t('footer.sector')}</h3>
              <ul className="space-y-4 text-sm text-slate-400">
                <li className="flex items-center gap-2 group cursor-pointer">
                  <div className="w-1.5 h-1.5 rounded-full border border-[#B32D6A] group-hover:bg-[#B32D6A] transition-colors"></div>
                  <span className="group-hover:text-white transition-colors">Home Service Builders</span>
                </li>
                <li className="flex items-center gap-2 group cursor-pointer">
                  <div className="w-1.5 h-1.5 rounded-full border border-[#B32D6A] group-hover:bg-[#B32D6A] transition-colors"></div>
                  <span className="group-hover:text-white transition-colors">SaaS & Tech</span>
                </li>
                <li className="flex items-center gap-2 group cursor-pointer">
                  <div className="w-1.5 h-1.5 rounded-full border border-[#B32D6A] group-hover:bg-[#B32D6A] transition-colors"></div>
                  <span className="group-hover:text-white transition-colors">Professional Services</span>
                </li>
                <li className="flex items-center gap-2 group cursor-pointer">
                  <div className="w-1.5 h-1.5 rounded-full border border-[#B32D6A] group-hover:bg-[#B32D6A] transition-colors"></div>
                  <span className="group-hover:text-white transition-colors">E-commerce Scale</span>
                </li>
                <li className="flex items-center gap-2 group cursor-pointer">
                  <div className="w-1.5 h-1.5 rounded-full border border-[#B32D6A] group-hover:bg-[#B32D6A] transition-colors"></div>
                  <span className="group-hover:text-white transition-colors">Local Authority</span>
                </li>
                <li className="flex items-center gap-2 group cursor-pointer">
                  <div className="w-1.5 h-1.5 rounded-full border border-[#B32D6A] group-hover:bg-[#B32D6A] transition-colors"></div>
                  <span className="group-hover:text-white transition-colors">B2B Lead Gen</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Award Badges Section */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-24">
            {[
              { name: 'Clutch', rating: '5.0', reviews: '50+ Reviews' },
              { name: 'awwwards.', status: 'Multiple Awarded' },
              { name: 'CSSDesignAwards', status: 'Multiple Awarded' },
              { name: 'Tech Behemoths', status: 'Trusted Partner' },
              { name: 'UpCity', status: 'Top Rated Agency' },
              { name: 'DesignRush', status: 'Top Web Design' }
            ].map((award, i) => (
              <div key={i} className="bg-white/5 border border-white/10 rounded-xl p-6 flex flex-col items-center justify-center text-center group hover:bg-white/10 transition-colors">
                <span className="text-white font-display font-bold text-lg mb-1">{award.name}</span>
                <div className="flex flex-col">
                  {award.rating && <span className="text-[#B32D6A] text-xs font-bold mb-1">★★★★★ {award.rating}</span>}
                  <span className="text-[10px] uppercase tracking-widest text-slate-500 group-hover:text-slate-300 transition-colors">{award.reviews || award.status}</span>
                </div>
              </div>
            ))}
          </div>
          
          {/* Bottom Bar */}
          <div className="flex flex-col lg:flex-row justify-between items-center pt-12 border-t border-white/10 gap-8">
            <div className="flex flex-col md:flex-row items-center gap-8 text-[10px] text-slate-500 font-mono uppercase tracking-widest">
              <p>{t('footer.rights')}</p>
              <div className="flex gap-6">
                <Link to="#" className="hover:text-white transition-colors">{t('footer.privacy')}</Link>
                <Link to="#" className="hover:text-white transition-colors">{t('footer.terms')}</Link>
                <Link to="#" className="hover:text-white transition-colors">{t('footer.cookie')}</Link>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <a href="#" className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-all">
                  <Facebook size={14} />
                </a>
                <a href="#" className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-all">
                  <Instagram size={14} />
                </a>
                <a href="#" className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-all">
                  <Twitter size={14} />
                </a>
                <a href="#" className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-all">
                  <Linkedin size={14} />
                </a>
              </div>
              <Link to="/contact">
                <button className="bg-[#B32D6A] text-white text-[10px] font-black uppercase tracking-[0.2em] px-6 py-3 rounded-full hover:bg-white hover:text-black transition-all shadow-lg shadow-[#B32D6A]/20">
                  {t('footer.speak')}
                </button>
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* AI Assistant Widget */}
      <AiAssistant />
    </div>
  );
};

export default Layout;