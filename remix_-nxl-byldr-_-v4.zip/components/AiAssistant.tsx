import React, { useState, useRef, useEffect, useMemo } from 'react';
import { MessageSquare, X, Send, Sparkles, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import { motion, useSpring, useMotionValue, AnimatePresence } from 'framer-motion';
import { createChatSession, sendMessageToGemini } from '../services/geminiService';
import { ChatMessage } from '../types';
import { Chat } from '@google/genai';

const MagneticButton: React.FC<{
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  repelRadius?: number;
  repelStrength?: number;
  id: string;
}> = ({ children, onClick, className, repelRadius = 150, repelStrength = 40, id }) => {
  const x = useSpring(0, { stiffness: 150, damping: 15 });
  const y = useSpring(0, { stiffness: 150, damping: 15 });
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!ref.current) return;

      const rect = ref.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      const distX = e.clientX - centerX;
      const distY = e.clientY - centerY;
      const distance = Math.sqrt(distX * distX + distY * distY);

      if (distance < repelRadius) {
        // Calculate push direction (opposite to mouse)
        const angle = Math.atan2(distY, distX);
        const pushX = Math.cos(angle + Math.PI) * (repelRadius - distance) * (repelStrength / repelRadius);
        const pushY = Math.sin(angle + Math.PI) * (repelRadius - distance) * (repelStrength / repelRadius);

        // Limit the push to stay within bounds
        x.set(pushX);
        y.set(pushY);
      } else {
        x.set(0);
        y.set(0);
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [repelRadius, repelStrength, x, y]);

  return (
    <motion.div
      ref={ref}
      style={{ x, y }}
      className={className}
      onClick={onClick}
    >
      {children}
    </motion.div>
  );
};

const ParticleWeb: React.FC<{ buttonRefs: React.RefObject<HTMLElement>[] }> = ({ buttonRefs }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const render = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const points: { x: number, y: number }[] = [];

      buttonRefs.forEach(ref => {
        if (ref.current) {
          const rect = ref.current.getBoundingClientRect();
          points.push({
            x: rect.left + rect.width / 2,
            y: rect.top + rect.height / 2
          });
        }
      });

      if (points.length >= 2) {
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
          ctx.lineTo(points[i].x, points[i].y);
        }
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.lineWidth = 1;
        ctx.setLineDash([5, 5]);
        ctx.stroke();

        // Draw some extra geometric lines around the buttons
        points.forEach(p => {
          ctx.beginPath();
          ctx.arc(p.x, p.y, 60, 0, Math.PI * 2);
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
          ctx.setLineDash([]);
          ctx.stroke();
        });
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animationFrameId);
  }, [buttonRefs]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-40"
    />
  );
};

const AiAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [hiddenButton, setHiddenButton] = useState<'speak' | 'book' | null>(null);
  const bookRef = useRef<HTMLDivElement>(null);
  const speakRef = useRef<HTMLButtonElement>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { 
      role: 'model', 
      text: 'Welcome to the Architect’s desk. We build high-level neural networks for businesses. Are you ready to initiate the Rapid Execution sequence for your territory?\n\n[BUILD MINE](/contact) [VIEW RESULTS](/results)' 
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatSessionRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && !chatSessionRef.current) {
      chatSessionRef.current = createChatSession();
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (text?: string) => {
    const messageText = text || inputValue;
    if (!messageText.trim() || !chatSessionRef.current) return;

    const userMsg: ChatMessage = { role: 'user', text: messageText };
    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    try {
      const responseText = await sendMessageToGemini(chatSessionRef.current, userMsg.text);
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "I'm having trouble connecting right now. Please try again later.", isError: true }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Custom component for Markdown links to render them as buttons
  const MarkdownLink = ({ href, children }: any) => {
    const isBuildMine = href === '/contact';
    const isResults = href === '/results';
    const isPortal = href === '/portal';

    if (isBuildMine || isResults || isPortal) {
      return (
        <button
          onClick={(e) => {
            e.preventDefault();
            if (isBuildMine) handleSend("I want to BUILD MINE");
            else if (isResults) handleSend("Show me the results");
            else if (isPortal) window.location.href = '/portal';
          }}
          className={`inline-block mt-2 mr-2 px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
            isBuildMine || isPortal
              ? 'bg-[#B32D6A] hover:bg-[#962659] text-white shadow-lg shadow-[#B32D6A]/20' 
              : 'bg-slate-700 hover:bg-slate-600 text-white border border-slate-600'
          }`}
        >
          {children}
        </button>
      );
    }

    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:underline">
        {children}
      </a>
    );
  };

  return (
    <div className="fixed bottom-10 right-10 z-50 flex flex-col items-end">
      {!isOpen && (
        <>
          <ParticleWeb buttonRefs={[bookRef, speakRef]} />
          <div className="flex items-center gap-6 relative">
            {/* Book a call circle */}
            {hiddenButton !== 'book' && (
              <MagneticButton id="book" className="transition-all duration-500">
                <Link 
                  to="/contact"
                  onClick={() => setHiddenButton('speak')}
                >
                  <div
                    ref={bookRef}
                    className="group relative flex items-center justify-center w-20 h-20 bg-[#B32D6A] rounded-full shadow-2xl shadow-[#B32D6A]/40 hover:scale-110 transition-transform duration-500 overflow-hidden border border-white/20"
                  >
                    <span className="text-white text-[9px] font-bold text-center px-2 leading-tight uppercase tracking-tighter">
                      Book<br/>a call
                    </span>
                    <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity"></div>
                  </div>
                </Link>
              </MagneticButton>
            )}

            {/* Speak To Us circle */}
            {hiddenButton !== 'speak' && (
              <MagneticButton id="speak">
                <button
                  ref={speakRef}
                  onClick={() => {
                    setIsOpen(true);
                    setHiddenButton('book');
                  }}
                  className="relative z-10 group flex items-center justify-center w-24 h-24 bg-[#B32D6A] rounded-full shadow-2xl shadow-[#B32D6A]/40 hover:scale-110 transition-transform duration-500 overflow-hidden border border-white/20"
                >
                  <span className="absolute top-3 right-3 w-2.5 h-2.5 bg-green-400 rounded-full border-2 border-black animate-pulse"></span>
                  <span className="text-white text-xs font-black text-center px-3 leading-none uppercase tracking-tighter">
                    Speak<br/>To Us
                  </span>
                  <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity"></div>
                </button>
              </MagneticButton>
            )}
          </div>
        </>
      )}

      {isOpen && (
        <div className="bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl w-[350px] sm:w-[400px] h-[600px] flex flex-col overflow-hidden animate-in slide-in-from-bottom-10 fade-in duration-300">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#30001D] to-slate-950 p-4 border-b border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-[#B32D6A]/20 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-[#B32D6A]" />
              </div>
              <div>
                <h3 className="font-semibold text-white text-sm">VSUALdigitalmedia AI Architect</h3>
                <p className="text-xs text-[#B32D6A] flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span>
                  Online
                </p>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-grow overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-slate-900">
            {messages.map((msg, idx) => (
              <div 
                key={idx} 
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm ${
                    msg.role === 'user' 
                      ? 'bg-[#B32D6A] text-white rounded-tr-sm' 
                      : 'bg-slate-900 text-slate-200 rounded-tl-sm border border-slate-800'
                  } ${msg.isError ? 'bg-red-900/50 border-red-800 text-red-200' : ''}`}
                >
                  <ReactMarkdown 
                    components={{
                      a: MarkdownLink
                    }}
                  >
                    {msg.text}
                  </ReactMarkdown>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-slate-900 rounded-2xl rounded-tl-sm px-4 py-3 border border-slate-800">
                  <Loader2 className="w-4 h-4 animate-spin text-[#B32D6A]" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 bg-slate-950 border-t border-slate-800">
            <div className="relative">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Ask about our trial..."
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-4 pr-12 py-3 text-sm text-white focus:outline-none focus:border-[#B32D6A] focus:ring-1 focus:ring-[#B32D6A] placeholder-slate-600"
              />
              <button 
                onClick={() => handleSend()}
                disabled={isLoading || !inputValue.trim()}
                className="absolute right-2 top-2 p-1.5 bg-[#B32D6A] hover:bg-[#962659] disabled:opacity-50 disabled:hover:bg-[#B32D6A] text-white rounded-lg transition-colors"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AiAssistant;