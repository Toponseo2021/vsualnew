import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, ShieldCheck, Users } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { Reveal } from './Reveal';
import GShieldLogo from './GShieldLogo';

interface ByldersGuardianProps {
  variant?: 'black' | 'white';
}

const ByldersGuardian: React.FC<ByldersGuardianProps> = ({ variant = 'black' }) => {
  const { t } = useLanguage();

  const isWhite = variant === 'white';

  return (
    <section className={`relative py-32 overflow-hidden ${isWhite ? 'bg-white text-black' : 'bg-black text-white'}`}>
      {/* Background Effect */}
      <motion.div 
        animate={{ 
          x: [0, 30, -30, 0],
          y: [0, -20, 20, 0],
          scale: [1, 1.2, 0.8, 1]
        }}
        transition={{ 
          duration: 15, 
          repeat: Infinity, 
          ease: "linear" 
        }}
        className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] opacity-20 blur-[120px] rounded-full -z-10 ${isWhite ? 'bg-[#B32D6A]/10' : 'bg-[#4B0082]'}`}
      />

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="flex flex-col items-center text-center mb-20">
          {/* Floating Glowing G-Shield Logo */}
          <motion.div
            animate={{ 
              y: [0, -20, 0],
              filter: ["drop-shadow(0 0 20px rgba(179, 45, 106, 0.3))", "drop-shadow(0 0 40px rgba(179, 45, 106, 0.6))", "drop-shadow(0 0 20px rgba(179, 45, 106, 0.3))"]
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
            className="mb-12"
          >
            <div className="w-24 h-24 bg-gradient-to-br from-[#B32D6A] to-[#801D48] rounded-3xl flex items-center justify-center shadow-2xl relative overflow-hidden group border-2 border-[#B32D6A]/30">
              <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity" />
              <GShieldLogo size={56} color="black" className="relative z-10 drop-shadow-sm" />
            </div>
          </motion.div>

          <Reveal>
            <h2 className="text-sm font-black uppercase tracking-[0.4em] text-[#B32D6A] mb-6 drop-shadow-[0_0_10px_rgba(179,45,106,0.3)]">
              THE BYLDRS GUARDIAN™
            </h2>
          </Reveal>
          
          <Reveal delay={0.2}>
            <h3 className={`text-4xl md:text-6xl font-display font-black uppercase tracking-tighter mb-8 max-w-3xl leading-[0.9] ${isWhite ? 'text-black' : 'text-white'}`}>
              {t('guardian.headline')}
            </h3>
          </Reveal>

          <Reveal delay={0.4}>
            <p className={`text-xl max-w-2xl font-light leading-relaxed ${isWhite ? 'text-slate-600' : 'text-slate-400'}`}>
              {t('guardian.body')}
            </p>
          </Reveal>
        </div>

        {/* The Three Pillars */}
        <div className="grid md:grid-cols-3 gap-12">
          <Reveal delay={0.6}>
            <div className={`p-10 rounded-[2rem] transition-colors group ${isWhite ? 'bg-slate-50 border border-slate-200 hover:border-[#B32D6A]/50' : 'bg-white/5 backdrop-blur-xl border border-white/10 hover:border-[#B32D6A]/30'}`}>
              <div className="w-12 h-12 bg-[#B32D6A]/10 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <ShieldCheck size={24} className="text-[#B32D6A]" />
              </div>
              <h4 className="text-xl font-display font-black uppercase tracking-tight mb-4">{t('guardian.pillar1_title')}</h4>
              <p className={`text-sm leading-relaxed ${isWhite ? 'text-slate-500' : 'text-slate-400'}`}>{t('guardian.pillar1_text')}</p>
            </div>
          </Reveal>

          <Reveal delay={0.7}>
            <div className={`p-10 rounded-[2rem] transition-colors group ${isWhite ? 'bg-slate-50 border border-slate-200 hover:border-[#B32D6A]/50' : 'bg-white/5 backdrop-blur-xl border border-white/10 hover:border-[#B32D6A]/30'}`}>
              <div className="w-12 h-12 bg-[#B32D6A]/10 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <CheckCircle size={24} className="text-[#B32D6A]" />
              </div>
              <h4 className="text-xl font-display font-black uppercase tracking-tight mb-4">{t('guardian.pillar2_title')}</h4>
              <p className={`text-sm leading-relaxed ${isWhite ? 'text-slate-500' : 'text-slate-400'}`}>{t('guardian.pillar2_text')}</p>
            </div>
          </Reveal>

          <Reveal delay={0.8}>
            <div className={`p-10 rounded-[2rem] transition-colors group ${isWhite ? 'bg-slate-50 border border-slate-200 hover:border-[#B32D6A]/50' : 'bg-white/5 backdrop-blur-xl border border-white/10 hover:border-[#B32D6A]/30'}`}>
              <div className="w-12 h-12 bg-[#B32D6A]/10 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Users size={24} className="text-[#B32D6A]" />
              </div>
              <h4 className="text-xl font-display font-black uppercase tracking-tight mb-4">{t('guardian.pillar3_title')}</h4>
              <p className={`text-sm leading-relaxed ${isWhite ? 'text-slate-500' : 'text-slate-400'}`}>{t('guardian.pillar3_text')}</p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
};

export default ByldersGuardian;
