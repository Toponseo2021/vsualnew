import React, { useEffect, useRef } from 'react';
import webGLFluidCustom from 'webgl-fluid-custom';
import { useLocation } from 'react-router-dom';

const FluidCursor: React.FC<{ interactive?: boolean }> = ({ interactive = true }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const location = useLocation();
  const isHomePage = location.pathname === '/';
  const isCareersPage = location.pathname === '/careers';
  const isApplyPage = location.pathname === '/apply';
  const isSpecialPage = isHomePage || isCareersPage || isApplyPage;

  useEffect(() => {
    if (canvasRef.current) {
      const fluid = webGLFluidCustom(canvasRef.current, {
        TRIGGER: 'hover',
        SIM_RESOLUTION: 256, // Higher resolution for silky, smooth wisps
        DENSITY_DISSIPATION: 0.996, // High linger for "Cigarette" effect
        VELOCITY_DISSIPATION: 0.999, // Persistent swirls
        PRESSURE: 0.8,
        CURL: isApplyPage ? 20 : (isCareersPage ? 200 : 150), // High vorticity for vortices
        SPLAT_RADIUS: 0.4, // Thicker, ink-like wisps
        SHADING: true,
        COLORFUL: false,
        PAUSED: false,
        COLOR_PALETTE: ['#FF3B5C', '#7000FF', '#FF00FF'], // Hard-locked 3-color palette
        BLOOM: true,
        BLOOM_ITERATIONS: 8,
        BLOOM_INTENSITY: 2.0, // Vibrant "Pop"
        BLOOM_THRESHOLD: 0.3, // More presence
        SUNRAYS: false,
        BACK_COLOR: { r: 0, g: 0, b: 0 }, // Pure Black background
        TRANSPARENT: true,
        GUI: false,
      });

      // Breathing / Idling effect
      const breathingInterval = setInterval(() => {
        if (isSpecialPage && fluid && typeof (fluid as any).splat === 'function') {
          const x = 0.5 + (Math.random() - 0.5) * 0.2;
          const y = 0.5 + (Math.random() - 0.5) * 0.2;
          const dx = (Math.random() - 0.5) * (isApplyPage ? 50 : (isCareersPage ? 500 : 100));
          const dy = (Math.random() - 0.5) * (isApplyPage ? 50 : (isCareersPage ? 500 : 100));
          try {
            // @ts-ignore
            fluid.splat(x, y, dx, dy);
          } catch (e) {
            console.warn('Fluid splat failed', e);
          }
        }
      }, isApplyPage ? 5000 : (isCareersPage ? 1000 : 3000));

      // Manual interaction for "Force" and "Vorticity"
      let lastX = 0;
      let lastY = 0;
      let lastTime = Date.now();

      const handleMouseMove = (e: MouseEvent) => {
        if (!interactive) return;
        if (canvasRef.current) {
          const event = new MouseEvent('mousemove', {
            clientX: e.clientX,
            clientY: e.clientY,
            bubbles: true,
            cancelable: true,
          });
          canvasRef.current.dispatchEvent(event);

          if (isSpecialPage && fluid && typeof (fluid as any).splat === 'function') {
            const x = e.clientX / window.innerWidth;
            const y = 1.0 - (e.clientY / window.innerHeight);
            
            const now = Date.now();
            const dt = Math.max(now - lastTime, 1);
            
            // Calculate velocity for "Push/Pull" effect
            const dx = (x - lastX) * (1000 / dt) * 500; 
            const dy = (y - lastY) * (1000 / dt) * 500;

            try {
              // @ts-ignore
              fluid.splat(x, y, dx, dy);
            } catch (e) {
              // Ignore
            }
            
            lastX = x;
            lastY = y;
            lastTime = now;
          }
        }
      };

      const handleTouchMove = (e: TouchEvent) => {
        if (!interactive) return;
        if (canvasRef.current && e.touches.length > 0) {
          const touch = e.touches[0];
          const event = new MouseEvent('mousemove', {
            clientX: touch.clientX,
            clientY: touch.clientY,
            bubbles: true,
            cancelable: true,
          });
          canvasRef.current.dispatchEvent(event);
        }
      };

      const handleMouseDown = (e: MouseEvent) => {
        if (!interactive) return;
        if (canvasRef.current) {
          const event = new MouseEvent('mousedown', {
            clientX: e.clientX,
            clientY: e.clientY,
            bubbles: true,
            cancelable: true,
          });
          canvasRef.current.dispatchEvent(event);
          
          if (isSpecialPage && fluid && typeof (fluid as any).splat === 'function') {
            const x = e.clientX / window.innerWidth;
            const y = 1.0 - (e.clientY / window.innerHeight);
            const dx = (Math.random() - 0.5) * (isCareersPage ? 4000 : 3000);
            const dy = (Math.random() - 0.5) * (isCareersPage ? 4000 : 3000);
            try {
              // @ts-ignore
              fluid.splat(x, y, dx, dy);
            } catch (e) {
              // Ignore
            }
          }
        }
      };

      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mousedown', handleMouseDown);
      window.addEventListener('touchmove', handleTouchMove, { passive: false });

      return () => {
        clearInterval(breathingInterval);
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mousedown', handleMouseDown);
        window.removeEventListener('touchmove', handleTouchMove);
      };
    }
  }, [location.pathname, interactive]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-[0] w-full h-full pointer-events-none"
      style={{ mixBlendMode: 'normal' }} // Normal blend mode since it's the background
    />
  );
};

export default FluidCursor;
