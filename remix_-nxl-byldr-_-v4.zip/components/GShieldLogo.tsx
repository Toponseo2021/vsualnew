import React from 'react';

interface GShieldLogoProps {
  size?: number;
  className?: string;
  color?: string;
}

export const GShieldLogo: React.FC<GShieldLogoProps> = ({ 
  size = 48, 
  className = "", 
  color = "currentColor" 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <path 
        d="M50 5L10 22V50C10 78 50 95 50 95C50 95 90 78 90 50V50H55V60H78C76 74 65 83 50 83C35 83 22 74 22 50V35L50 22L78 35V42H90V22L50 5Z" 
        fill={color} 
      />
    </svg>
  );
};

export default GShieldLogo;
