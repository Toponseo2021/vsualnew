import React, { useEffect, useRef } from 'react';
import { motion, useSpring, useMotionValue } from 'framer-motion';

export const CustomCursor: React.FC = () => {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const autonomousX = useMotionValue(0);
  const autonomousY = useMotionValue(0);

  // Spring configuration for the "soft bounce" feel
  const springConfig = { damping: 20, stiffness: 120, mass: 0.8 };
  const cursorX = useSpring(mouseX, springConfig);
  const cursorY = useSpring(mouseY, springConfig);
  
  const lastMousePos = useRef({ x: 0, y: 0 });
  const idleTimer = useRef<number | null>(null);
  const isIdle = useRef(false);

  useEffect(() => {
    let angle = 0;
    let radius = 0;
    let targetRadius = 30;
    let frameId: number;

    const animateAutonomous = () => {
      if (isIdle.current) {
        // Wandering behavior
        angle += 0.02;
        radius += (targetRadius - radius) * 0.05;
        
        if (Math.abs(targetRadius - radius) < 1) {
          targetRadius = 20 + Math.random() * 40;
        }

        const ox = Math.cos(angle) * radius;
        const oy = Math.sin(angle) * radius;
        
        autonomousX.set(ox);
        autonomousY.set(oy);
      } else {
        // Smoothly reset offset when active
        autonomousX.set(autonomousX.get() * 0.9);
        autonomousY.set(autonomousY.get() * 0.9);
      }
      frameId = requestAnimationFrame(animateAutonomous);
    };

    const handleMouseMove = (e: MouseEvent) => {
      lastMousePos.current = { x: e.clientX, y: e.clientY };
      mouseX.set(e.clientX - 10);
      mouseY.set(e.clientY - 10);
      
      isIdle.current = false;
      if (idleTimer.current) window.clearTimeout(idleTimer.current);
      
      idleTimer.current = window.setTimeout(() => {
        isIdle.current = true;
      }, 1000) as unknown as number;
    };

    window.addEventListener('mousemove', handleMouseMove);
    frameId = requestAnimationFrame(animateAutonomous);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(frameId);
      if (idleTimer.current) window.clearTimeout(idleTimer.current);
    };
  }, [mouseX, mouseY, autonomousX, autonomousY]);

  return (
    <motion.div
      className="fixed top-0 left-0 w-5 h-5 border-2 border-white rounded-full pointer-events-none z-[9999] mix-blend-difference shadow-[0_0_20px_rgba(255,255,255,0.6)]"
      style={{
        x: cursorX,
        y: cursorY,
        translateX: autonomousX,
        translateY: autonomousY,
      }}
      animate={{
        scale: [1, 1.2, 1],
        borderWidth: ["2px", "1px", "2px"],
      }}
      transition={{
        duration: 3,
        repeat: Infinity,
        ease: "easeInOut"
      }}
    >
      {/* Little "mind" dot inside */}
      <motion.div 
        className="absolute inset-0 m-auto w-1 h-1 bg-white rounded-full"
        animate={{
          scale: [1, 2, 1],
          opacity: [0.5, 1, 0.5],
        }}
        transition={{
          duration: 1.5,
          repeat: Infinity,
        }}
      />
      
      {/* Subtle connection lines effect */}
      <div className="absolute inset-[-20px] opacity-20 pointer-events-none">
        <svg width="60" height="60" viewBox="0 0 60 60">
          <motion.line 
            x1="30" y1="30" x2="10" y2="10" 
            stroke="white" strokeWidth="0.5"
            animate={{ opacity: [0, 1, 0], x2: [10, 5, 10], y2: [10, 15, 10] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <motion.line 
            x1="30" y1="30" x2="50" y2="20" 
            stroke="white" strokeWidth="0.5"
            animate={{ opacity: [0, 1, 0], x2: [50, 55, 50], y2: [20, 25, 20] }}
            transition={{ duration: 2.5, repeat: Infinity, delay: 0.5 }}
          />
        </svg>
      </div>
    </motion.div>
  );
};
