import React from 'react';
import { motion } from 'framer-motion';

export const LogoReveal: React.FC<{ isCompact?: boolean; onComplete?: () => void }> = ({ isCompact, onComplete }) => {

  if (isCompact) return null;

  return (
    <div className="relative w-full h-screen flex items-center justify-center overflow-hidden perspective-[1200px] bg-[#B32D6A]">
      <motion.div
        initial={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        onAnimationComplete={() => onComplete?.()}
        className="absolute inset-0 z-[100] flex items-center justify-center"
      >
        {/* White Box Animation */}
        <motion.div
          initial={{ scale: 0, rotate: -45, borderRadius: "12px" }}
          animate={{ 
            scale: [0, 1, 1],
            rotate: [-45, 0, 0],
            width: ["80px", "80px", "480px"],
            height: ["80px", "80px", "160px"],
          }}
          transition={{ 
            duration: 2,
            times: [0, 0.4, 1],
            ease: [0.22, 1, 0.36, 1]
          }}
          className="bg-white relative flex items-center justify-center overflow-hidden shadow-2xl"
        >
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="flex items-center gap-8 px-10"
          >
            {/* V Logo */}
            <div className="relative shrink-0">
              <svg viewBox="0 0 144 144" className="w-20 h-20" xmlns="http://www.w3.org/2000/svg">
                <polygon fill="#B32D6A" points="41.66,143.61 0.32,143.61 0.37,0.59" />
                <polygon fill="#B32D6A" points="143.68,0.34 102.39,143.36 143.72,143.36" />
                <polygon fill="#B32D6A" points="71.46,98.11 93.64,36.18 87.29,39.32 95.96,0.57 47.65,0.57 62.18,73.05 67.34,68.55" />
              </svg>
            </div>
            
            <div className="flex flex-col border-l-2 border-black/10 pl-8">
              <div className="text-5xl font-display font-black tracking-tighter text-black leading-none mb-1">
                VSUAL
              </div>
              <div className="text-[12px] font-display font-bold tracking-[0.4em] text-black uppercase opacity-40">
                Digital Media
              </div>
            </div>
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  );
};






