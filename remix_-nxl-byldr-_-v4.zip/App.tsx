import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import { LanguageProvider } from './contexts/LanguageContext';

// Lazy load pages for performance
const Home = React.lazy(() => import('./pages/Home'));
const Services = React.lazy(() => import('./pages/Services'));
const Ecosystem = React.lazy(() => import('./pages/Ecosystem'));
const Insights = React.lazy(() => import('./pages/Insights'));
const About = React.lazy(() => import('./pages/About'));
const Contact = React.lazy(() => import('./pages/Contact'));
const Engine = React.lazy(() => import('./pages/Engine'));
const Results = React.lazy(() => import('./pages/Results'));
const ClientPortal = React.lazy(() => import('./pages/ClientPortal'));
const Careers = React.lazy(() => import('./pages/Careers'));
const Apply = React.lazy(() => import('./pages/Apply'));
const FAQ = React.lazy(() => import('./pages/FAQ'));
const BuildMine = React.lazy(() => import('./pages/BuildMine'));

// Loading component
const Loading = () => (
  <div className="min-h-screen bg-slate-950 flex items-center justify-center">
    <div className="w-8 h-8 border-2 border-[#B32D6A] border-t-transparent rounded-full animate-spin"></div>
  </div>
);

function App() {
  return (
    <LanguageProvider>
      <Router>
        <React.Suspense fallback={<Loading />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/services" element={<Services />} />
            <Route path="/ecosystem" element={<Ecosystem />} />
            <Route path="/insights" element={<Insights />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/engine" element={<Engine />} />
            <Route path="/results" element={<Results />} />
            <Route path="/portal" element={<ClientPortal />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/apply" element={<Apply />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/build" element={<BuildMine />} />
          </Routes>
        </React.Suspense>
      </Router>
    </LanguageProvider>
  );
}

export default App;