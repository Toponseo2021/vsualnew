import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { LogoReveal } from '../components/LogoReveal';
import Layout from '../components/Layout';
import { useLanguage } from '../contexts/LanguageContext';
import ByldersGuardian from '../components/ByldersGuardian';
import { Reveal } from '../components/Reveal';

const EnginePage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <Layout>
      <div className="min-h-screen bg-black text-white font-sans relative overflow-x-hidden">
        
        <div className="relative z-[5]">
          {/* Hero Section */}
          <section className="pt-40 pb-24 px-6 max-w-7xl mx-auto">
                <Reveal>
                  <div className="inline-block px-4 py-1.5 bg-white/5 border border-white/10 rounded-full text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-white/60">
                    {t('engine.badge')}
                  </div>
                </Reveal>
                <Reveal delay={0.2}>
                  <h1 className="text-6xl md:text-9xl font-display font-black leading-[0.85] mb-12 tracking-tighter uppercase text-white">
                    {t('engine.hero_title')} <br/>
                    <span className="text-[#B32D6A]">{t('engine.hero_accent')}</span>
                  </h1>
                </Reveal>
                <Reveal delay={0.4}>
                  <p className="text-xl md:text-3xl text-slate-400 leading-relaxed max-w-4xl font-light">
                    {t('engine.hero_text')}
                  </p>
                </Reveal>
              </section>

              {/* 15-Day Sprint Visualizer */}
              <section className="py-32 px-6 max-w-7xl mx-auto overflow-hidden">
                <div className="flex flex-col md:flex-row items-center justify-between gap-20">
                  <div className="md:w-1/2">
                    <Reveal>
                      <h2 className="text-4xl md:text-6xl font-display font-black mb-8 tracking-tighter uppercase text-white">
                        {t('engine.sprint_title')}
                      </h2>
                    </Reveal>
                    <Reveal delay={0.2}>
                      <p className="text-xl text-slate-400 leading-relaxed mb-12">
                        {t('engine.sprint_text')}
                      </p>
                    </Reveal>
                    <Reveal delay={0.4}>
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 rounded-full bg-[#B32D6A] flex items-center justify-center font-black text-white text-2xl shadow-xl shadow-[#B32D6A]/20">
                          15
                        </div>
                        <div className="text-sm font-black uppercase tracking-widest text-white">
                          {t('engine.sprint_badge')}
                        </div>
                      </div>
                    </Reveal>
                  </div>

                  <div className="md:w-1/2 w-full relative pt-20">
                    {/* Timeline Line */}
                    <div className="absolute top-1/2 left-0 w-full h-[2px] bg-white/10 -translate-y-1/2">
                      <motion.div 
                        initial={{ width: 0 }}
                        whileInView={{ width: '100%' }}
                        viewport={{ once: true }}
                        transition={{ duration: 2, ease: "easeInOut" }}
                        className="h-full bg-[#B32D6A]"
                      />
                    </div>

                    <div className="flex justify-between relative z-10">
                      <div className="flex flex-col items-center">
                        <div className="w-4 h-4 rounded-full bg-white mb-4" />
                        <span className="text-[10px] font-black uppercase tracking-widest text-white/40">{t('engine.sprint_day0')}</span>
                      </div>
                      
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.5 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        transition={{ delay: 1.5, type: "spring" }}
                        className="flex flex-col items-center"
                      >
                        <div className="w-6 h-6 rounded-full bg-[#B32D6A] mb-4 shadow-lg shadow-[#B32D6A]/40" />
                        <span className="text-sm font-black uppercase tracking-widest text-[#B32D6A]">
                          {t('engine.sprint_day15')}
                        </span>
                      </motion.div>
                    </div>

                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 2 }}
                      className="mt-12 text-center"
                    >
                      <span className="text-2xl font-display font-black uppercase tracking-tighter text-white">
                        15 DAYS TO FOUNDATION
                      </span>
                    </motion.div>
                  </div>
                </div>
              </section>

              {/* Kaizen Modules */}
              <section className="py-32 px-6 max-w-7xl mx-auto">
                <div className="mb-20">
                  <Reveal>
                    <h2 className="text-4xl md:text-7xl font-display font-black mb-8 tracking-tighter uppercase text-white">
                      {t('engine.kaizen_title')}
                    </h2>
                  </Reveal>
                  <Reveal delay={0.2}>
                    <p className="text-2xl text-slate-400 max-w-4xl font-light leading-relaxed">
                      {t('engine.kaizen_text')}
                    </p>
                  </Reveal>
                </div>
                
                <div className="grid md:grid-cols-3 gap-10">
                  {[
                    { title: t('engine.kaizen_card1_title'), text: t('engine.kaizen_card1_text') },
                    { title: t('engine.kaizen_card2_title'), text: t('engine.kaizen_card2_text') },
                    { title: t('engine.kaizen_card3_title'), text: t('engine.kaizen_card3_text') }
                  ].map((card, i) => (
                    <Reveal key={i} delay={i * 0.1}>
                      <motion.div 
                        whileHover={{ y: -5, x: 5 }}
                        className="p-12 bg-white/5 rounded-[2rem] shadow-[0_10px_40px_rgba(0,0,0,0.2)] border border-transparent hover:border-[#B32D6A] transition-all duration-500 group"
                      >
                        <h3 className="text-lg font-black uppercase tracking-widest mb-6 text-[#B32D6A] group-hover:translate-x-2 transition-transform">
                          {card.title}
                        </h3>
                        <p className="text-slate-400 leading-relaxed text-lg">
                          {card.text}
                        </p>
                      </motion.div>
                    </Reveal>
                  ))}
                </div>
              </section>

              {/* 3-Step Formula */}
              <section className="py-32 px-6 max-w-7xl mx-auto border-y border-white/5">
                <Reveal>
                  <h2 className="text-center text-5xl md:text-7xl font-display font-black mb-24 tracking-tighter uppercase text-white">
                    {t('engine.formula_title')}
                  </h2>
                </Reveal>
                <div className="grid md:grid-cols-3 gap-20">
                  {[
                    { step: '01', title: t('engine.formula_step1_title'), text: t('engine.formula_step1_text') },
                    { step: '02', title: t('engine.formula_step2_title'), text: t('engine.formula_step2_text') },
                    { step: '03', title: t('engine.formula_step3_title'), text: t('engine.formula_step3_text') }
                  ].map((item, i) => (
                    <Reveal key={i} delay={i * 0.2}>
                      <div className="text-center group">
                        <div className="text-9xl font-display font-black text-white/[0.03] mb-[-4rem] group-hover:text-[#B32D6A]/5 transition-colors">
                          {item.step}
                        </div>
                        <h3 className="text-2xl font-black mb-6 uppercase tracking-tight text-white relative z-10">
                          {item.title}
                        </h3>
                        <p className="text-slate-400 leading-relaxed relative z-10">
                          {item.text}
                        </p>
                      </div>
                    </Reveal>
                  ))}
                </div>
              </section>

              {/* THE BYLDRS GUARDIAN™ */}
              <ByldersGuardian variant="black" />

              {/* Performance Report Section (Physical Print-out Aesthetic) */}
              <section className="py-40 px-6 max-w-5xl mx-auto">
                <Reveal>
                  <div className="p-12 md:p-20 bg-white text-black border-2 border-black shadow-[20px_20px_0px_rgba(255,255,255,0.05)] relative overflow-hidden">
                    {/* Print-out details */}
                    <div className="absolute top-0 right-0 p-4 text-[8px] font-mono uppercase opacity-30">
                      Ref: NXL-ENG-2024-PRT<br/>
                      Auth: VSUAL_STRAT_UNIT
                    </div>

                    <div className="flex flex-col md:flex-row justify-between items-start mb-20 gap-8">
                      <div>
                        <div className="text-[10px] font-black tracking-[0.4em] uppercase mb-4 text-black/40">
                          {t('engine.visual_badge')}
                        </div>
                        <h2 className="text-5xl font-display font-black tracking-tighter uppercase">
                          NXL BYLDR™ <span className="text-sm align-top">©</span>
                        </h2>
                      </div>
                      <div className="text-right font-mono text-xs border-l-2 border-black pl-6 py-2">
                        <span className="opacity-40">{t('engine.visual_client')}</span><br/>
                        <span className="font-bold">[CONFIDENTIAL_PARTNER]</span><br/>
                        <span className="opacity-40 mt-2 block">{t('engine.visual_period')}</span>
                        <span className="font-bold">Q1_EXECUTION_CYCLE</span>
                      </div>
                    </div>

                    <div className="space-y-20">
                      {/* Section 1 */}
                      <div className="border-t-2 border-black pt-8">
                        <h4 className="text-xs font-black uppercase tracking-[0.3em] mb-10 flex items-center gap-4">
                          <span className="w-2 h-2 bg-black rounded-full" />
                          {t('engine.visual_reach_title')}
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                          <div className="border-l border-black/10 pl-6">
                            <div className="text-4xl font-black mb-1">$500.00</div>
                            <div className="text-[10px] uppercase font-bold text-black/40">{t('engine.visual_reach_spend')}</div>
                          </div>
                          <div className="border-l border-black/10 pl-6">
                            <div className="text-4xl font-black mb-1">12,500</div>
                            <div className="text-[10px] uppercase font-bold text-black/40">{t('engine.visual_reach_reached')}</div>
                          </div>
                          <div className="border-l border-black/10 pl-6">
                            <div className="text-4xl font-black mb-1">450</div>
                            <div className="text-[10px] uppercase font-bold text-black/40">{t('engine.visual_reach_clicks')}</div>
                          </div>
                        </div>
                      </div>

                      {/* Section 2 */}
                      <div className="border-t-2 border-black pt-8">
                        <h4 className="text-xs font-black uppercase tracking-[0.3em] mb-10 flex items-center gap-4">
                          <span className="w-2 h-2 bg-black rounded-full" />
                          {t('engine.visual_catch_title')}
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                          <div className="border-l border-black/10 pl-6">
                            <div className="text-4xl font-black mb-1">20</div>
                            <div className="text-[10px] uppercase font-bold text-black/40">{t('engine.visual_catch_leads')}</div>
                          </div>
                          <div className="border-l border-black/10 pl-6">
                            <div className="text-4xl font-black mb-1">18</div>
                            <div className="text-[10px] uppercase font-bold text-black/40">{t('engine.visual_catch_convos')}</div>
                          </div>
                          <div className="border-l border-black/10 pl-6">
                            <div className="text-4xl font-black mb-1">5</div>
                            <div className="text-[10px] uppercase font-bold text-black/40">{t('engine.visual_catch_meetings')}</div>
                          </div>
                        </div>
                      </div>

                      {/* Section 3 - The Result */}
                      <div className="pt-12 border-t-4 border-black bg-black/5 -mx-12 md:-mx-20 px-12 md:px-20 pb-12">
                        <h4 className="text-xs font-black uppercase tracking-[0.3em] mb-10 text-black">
                          {t('engine.visual_gold_title')}
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 items-end">
                          <div>
                            <div className="text-6xl font-black mb-1">2</div>
                            <div className="text-[10px] uppercase font-bold text-black/40">{t('engine.visual_gold_jobs')}</div>
                          </div>
                          <div>
                            <div className="text-6xl font-black mb-1">$10,000.00+</div>
                            <div className="text-[10px] uppercase font-bold text-black/40">{t('engine.visual_gold_revenue')}</div>
                          </div>
                          <div className="bg-black text-white p-8 rounded-none shadow-2xl">
                            <div className="text-5xl font-black text-[#B32D6A] mb-2">2,000%</div>
                            <div className="text-[10px] uppercase font-bold text-white/40">{t('engine.visual_gold_roi')}</div>
                          </div>
                        </div>
                      </div>

                      <div className="pt-12 text-center">
                        <p className="text-2xl md:text-3xl font-display font-black italic text-black/80 leading-tight">
                          {t('engine.visual_quote')}
                        </p>
                      </div>
                    </div>

                    {/* Footer Stamps */}
                    <div className="mt-20 flex justify-between items-end">
                      <div className="flex gap-4">
                        <div className="w-16 h-16 border-4 border-black/10 rounded-full flex items-center justify-center text-[8px] font-black text-black/20 rotate-[-15deg]">
                          VERIFIED
                        </div>
                        <div className="w-16 h-16 border-4 border-[#B32D6A]/20 rounded-full flex items-center justify-center text-[8px] font-black text-[#B32D6A]/20 rotate-[10deg]">
                          NXL_BYLDR
                        </div>
                      </div>
                      <div className="text-[10px] font-mono opacity-20">
                        [END_OF_REPORT]
                      </div>
                    </div>
                  </div>
                </Reveal>
              </section>

              {/* Final CTA */}
              <section className="py-32 bg-black text-white text-center">
                <Reveal>
                  <h2 className="text-5xl md:text-8xl font-display font-black mb-12 tracking-tighter uppercase">
                    READY TO <span className="text-[#B32D6A]">INITIALIZE?</span>
                  </h2>
                  <Link to="/build">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-12 py-6 bg-white text-black rounded-full font-black uppercase tracking-[0.2em] text-lg shadow-2xl shadow-white/10"
                    >
                      Build Mine
                    </motion.button>
                  </Link>
                </Reveal>
              </section>
            </div>
          </div>
    </Layout>
  );
};

export default EnginePage;
