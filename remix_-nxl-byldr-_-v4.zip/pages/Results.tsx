import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Star, Play, X, Linkedin, ExternalLink, Globe } from 'lucide-react';
import Layout from '../components/Layout';
import { Reveal } from '../components/Reveal';
import { useLanguage } from '../contexts/LanguageContext';
import ByldersGuardian from '../components/ByldersGuardian';

interface ClientResult {
  id: string;
  name: string;
  industry: string;
  goal: string;
  mockupDesktop: string;
  mockupMobile: string;
  videoUrl: string;
  smokeColor: 'red' | 'purple';
}

const CLIENTS: ClientResult[] = [
  {
    id: 'snewroof',
    name: 'SNEWROOF',
    industry: 'Roofing Infrastructure',
    goal: 'Engine Goal: Multi-County Revenue Infrastructure.',
    mockupDesktop: 'https://picsum.photos/seed/roofing-desktop/800/600',
    mockupMobile: 'https://picsum.photos/seed/roofing-mobile/300/600',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ', // Placeholder
    smokeColor: 'red',
  },
  {
    id: 'american-air',
    name: 'American Air Duct',
    industry: 'HVAC Systems',
    goal: 'Engine Goal: 8-Channel Lead Velocity & Automation.',
    mockupDesktop: 'https://picsum.photos/seed/hvac-desktop/800/600',
    mockupMobile: 'https://picsum.photos/seed/hvac-mobile/300/600',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    smokeColor: 'red',
  },
  {
    id: 'nxt-lvl',
    name: 'NXT LVL Landscape',
    industry: 'Outdoor Architecture',
    goal: 'Engine Goal: Legacy Craft & High-Vorticity Visuals.',
    mockupDesktop: 'https://picsum.photos/seed/garden-desktop/800/600',
    mockupMobile: 'https://picsum.photos/seed/garden-mobile/300/600',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    smokeColor: 'purple',
  },
  {
    id: 'iwater',
    name: 'iWater',
    industry: 'Purification Tech',
    goal: 'Engine Goal: Precision ROI & Efficiency Logic.',
    mockupDesktop: 'https://picsum.photos/seed/water-desktop/800/600',
    mockupMobile: 'https://picsum.photos/seed/water-mobile/300/600',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    smokeColor: 'red',
  },
  {
    id: 'jp-plastering',
    name: 'JP Plastering',
    industry: 'Surface Engineering',
    goal: 'Engine Goal: High-Ticket Trust & Surface Engineering.',
    mockupDesktop: 'https://picsum.photos/seed/plaster-desktop/800/600',
    mockupMobile: 'https://picsum.photos/seed/plaster-mobile/300/600',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    smokeColor: 'purple',
  },
];

const ResultCard: React.FC<{ client: ClientResult }> = ({ client }) => {
  const [isVideoOpen, setIsVideoOpen] = useState(false);
  const [isVideoLoading, setIsVideoLoading] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handlePlayClick = () => {
    setIsVideoOpen(true);
    setIsVideoLoading(true);
    // Simulate loading time
    setTimeout(() => setIsVideoLoading(false), 2000);
  };

  return (
    <motion.div
      layout
      ref={cardRef}
      className="relative group h-full"
    >
      {/* Smoke Background Effect - Rolling Smoke */}
      <motion.div 
        animate={{ 
          x: [0, 15, -15, 0],
          y: [0, -10, 10, 0],
          scale: [1, 1.1, 0.9, 1]
        }}
        transition={{ 
          duration: 10, 
          repeat: Infinity, 
          ease: "linear" 
        }}
        className={`absolute -inset-10 opacity-10 group-hover:opacity-30 transition-opacity duration-1000 blur-[80px] rounded-full -z-10 ${
          client.smokeColor === 'red' ? 'bg-[#FF3B5C]' : 'bg-[#7000FF]'
        }`} 
      />

      <div className="bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2.5rem] overflow-hidden flex flex-col h-full shadow-2xl group-hover:border-white/20 transition-colors">
        {/* Media Section */}
        <div className="relative aspect-video overflow-hidden bg-black/40">
          <AnimatePresence mode="wait">
            {!isVideoOpen ? (
              <motion.div
                key="mockup"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="relative w-full h-full"
              >
                {/* Layered Mockups */}
                <div className="absolute inset-0 p-6 flex items-center justify-center">
                  <div className="relative w-full h-full">
                    {/* Desktop Mockup */}
                    <img 
                      src={client.mockupDesktop} 
                      alt={`${client.name} Desktop`}
                      className="w-[85%] h-auto rounded-lg shadow-2xl border border-white/10 translate-y-4"
                      referrerPolicy="no-referrer"
                    />
                    {/* Mobile Mockup */}
                    <img 
                      src={client.mockupMobile} 
                      alt={`${client.name} Mobile`}
                      className="absolute right-0 bottom-0 w-[30%] h-auto rounded-2xl shadow-2xl border-4 border-black z-10"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>

                {/* Play Button Overlay */}
                <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/40 transition-colors">
                  <motion.button
                    onClick={handlePlayClick}
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="w-16 h-16 bg-[#B32D6A] rounded-full flex items-center justify-center text-white shadow-lg shadow-[#B32D6A]/40 hover:bg-white hover:text-black transition-colors"
                  >
                    <Play fill="currentColor" size={24} className="ml-1" />
                  </motion.button>
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-[10px] font-black uppercase tracking-[0.2em] text-white opacity-0 group-hover:opacity-100 transition-opacity">
                    Watch Execution Report
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="video"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute inset-0"
              >
                {isVideoLoading ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-black">
                    <motion.div
                      animate={{ opacity: [0.4, 1, 0.4], scale: [0.95, 1.05, 0.95] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                      className="text-[#B32D6A] font-display font-black text-sm uppercase tracking-[0.4em]"
                    >
                      System Initializing
                    </motion.div>
                    <div className="mt-4 w-32 h-1 bg-white/10 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: '100%' }}
                        transition={{ duration: 2 }}
                        className="h-full bg-[#B32D6A]"
                      />
                    </div>
                  </div>
                ) : (
                  <>
                    <iframe
                      src={`${client.videoUrl}?autoplay=1`}
                      className="w-full h-full"
                      allow="autoplay; encrypted-media"
                      allowFullScreen
                    />
                    <button
                      onClick={() => setIsVideoOpen(false)}
                      className="absolute top-4 right-4 w-8 h-8 bg-black/60 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-[#B32D6A] transition-colors z-20"
                    >
                      <X size={16} />
                    </button>
                  </>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Content Section */}
        <div className="p-8 flex flex-col flex-grow">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-2xl font-display font-black text-white tracking-tighter mb-1">
                {client.name}
              </h3>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-[#B32D6A]">
                {client.industry}
              </p>
            </div>
          </div>

          <p className="text-white font-display font-bold text-lg leading-tight mb-8">
            {client.goal}
          </p>

          <div className="mt-auto pt-6 border-t border-white/5 flex items-center justify-between">
            {/* Social Proof Row */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3 opacity-40 grayscale hover:grayscale-0 transition-all">
                <Linkedin size={14} className="text-white" />
                <Globe size={14} className="text-white" /> {/* GMB Placeholder */}
                <Star size={14} className="text-white" /> {/* Yelp Placeholder */}
              </div>
              <div className="flex gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={10} fill="#FFD700" className="text-[#FFD700]" />
                ))}
              </div>
            </div>
            <button className="text-white/40 hover:text-[#B32D6A] transition-colors">
              <ExternalLink size={16} />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const ResultsPage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <Layout>
      <div className="min-h-screen bg-black text-white font-sans selection:bg-[#B32D6A]/30 pt-[100px] pb-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
          
          {/* Header */}
          <Reveal>
            <div className="mb-20">
              <div className="inline-block px-4 py-1.5 bg-[#B32D6A]/10 border border-[#B32D6A]/20 rounded-full text-[10px] font-black uppercase tracking-[0.3em] text-[#B32D6A] mb-8">
                Execution Proof
              </div>
              <h1 className="text-5xl md:text-8xl font-display font-black leading-[0.9] mb-8 tracking-tighter uppercase relative">
                THE RESULTS: <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF3B5C] via-[#FF00FF] to-[#7000FF]">Proof of the Engine</span>
              </h1>
              <p className="text-xl text-slate-400 max-w-2xl font-light leading-relaxed">
                We don't sell dreams. We engineer revenue. Explore the "Hard Knocks" execution reports of our elite partners.
              </p>
            </div>
          </Reveal>

          {/* Masonry Grid */}
          <div className="columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8">
            {CLIENTS.map((client, idx) => (
              <Reveal key={client.id} delay={idx * 0.1}>
                <div className="break-inside-avoid mb-8">
                  <ResultCard client={client} />
                </div>
              </Reveal>
            ))}
          </div>

          <ByldersGuardian />

          {/* Bottom CTA */}
          <Reveal delay={0.5}>
            <div className="mt-32 p-12 bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-[3rem] text-center relative overflow-hidden group">
              <div className="absolute inset-0 bg-[#B32D6A]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
              <h2 className="text-3xl md:text-5xl font-display font-black uppercase tracking-tighter mb-6 relative z-10">
                Ready to Initialize Your Engine?
              </h2>
              <p className="text-slate-400 mb-10 max-w-xl mx-auto relative z-10">
                Stop guessing. Start executing. Join the circle of high-performance businesses scaling with NXL BYLDR.
              </p>
              <Link to="/build">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-[#B32D6A] text-white px-12 py-5 rounded-full font-black uppercase tracking-[0.2em] text-sm shadow-2xl shadow-[#B32D6A]/30 relative z-10"
                >
                  Build Mine
                </motion.button>
              </Link>
            </div>
          </Reveal>
        </div>
      </div>
    </Layout>
  );
};

export default ResultsPage;
