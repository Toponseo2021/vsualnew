import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

import Layout from '../components/Layout';

const Services: React.FC = () => {
  const { t } = useLanguage();
  const [activeService, setActiveService] = useState<number | null>(0);

  const services = [
    {
      id: 0,
      title: t('services.mkt_title'),
      desc: t('services.mkt_desc'),
      tags: ['SEO', 'PPC', 'Analytics', 'Strategy'],
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2015&auto=format&fit=crop"
    },
    {
      id: 1,
      title: t('services.dev_title'),
      desc: t('services.dev_desc'),
      tags: ['React', 'Next.js', 'Node', 'Cloud'],
      image: "https://images.unsplash.com/photo-1555099962-4199c345e5dd?q=80&w=2070&auto=format&fit=crop"
    },
    {
      id: 2,
      title: t('services.ai_title'),
      desc: t('services.ai_desc'),
      tags: ['LLMs', 'Automation', 'Agents', 'Python'],
      image: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=1965&auto=format&fit=crop"
    },
    {
      id: 3,
      title: t('services.design_title'),
      desc: t('services.design_desc'),
      tags: ['UI/UX', 'Figma', 'Motion', 'Brand'],
      image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?q=80&w=2000&auto=format&fit=crop"
    }
  ];

  return (
    <Layout>
      <div className="bg-white min-h-screen pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col md:flex-row gap-12 lg:gap-24">
            
            {/* List Section */}
            <div className="w-full lg:w-1/2 z-10">
              <h1 className="text-5xl font-display font-bold text-black mb-16">{t('services.title')}</h1>
              
              <div className="flex flex-col">
                {services.map((service, index) => (
                  <div 
                    key={service.id}
                    onMouseEnter={() => setActiveService(index)}
                    className={`group border-t border-slate-100 py-10 cursor-pointer transition-all duration-300 ${activeService === index ? 'opacity-100' : 'opacity-40 hover:opacity-100'}`}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <span className="font-mono text-sm text-[#B32D6A]">0{index + 1}</span>
                      <ArrowUpRight className={`text-black transition-transform duration-300 ${activeService === index ? 'rotate-45' : 'group-hover:rotate-45'}`} />
                    </div>
                    <h2 className="text-3xl md:text-4xl font-display font-bold text-black mb-4">{service.title}</h2>
                    <p className="text-slate-600 text-lg mb-6 max-w-md">{service.desc}</p>
                    
                    <div className="flex flex-wrap gap-2">
                      {service.tags.map(tag => (
                        <span key={tag} className="px-3 py-1 rounded-full border border-slate-200 text-xs text-slate-500 uppercase tracking-wider">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
                <div className="border-t border-slate-100"></div>
              </div>
            </div>

            {/* Sticky Image Reveal Section */}
            <div className="hidden lg:block w-1/2 relative">
               <div className="sticky top-32 h-[600px] w-full rounded-2xl overflow-hidden border border-slate-100">
                  <AnimatePresence mode="wait">
                    {activeService !== null && (
                      <motion.img
                        key={activeService}
                        src={services[activeService].image}
                        initial={{ opacity: 0, scale: 1.1 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.5 }}
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                    )}
                  </AnimatePresence>
                  <div className="absolute inset-0 bg-black/20"></div>
               </div>
            </div>
          </div>

        </div>
      </div>
    </Layout>
  );
};

export default Services;