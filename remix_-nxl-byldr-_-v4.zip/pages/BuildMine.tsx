import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Rocket, Shield, Cpu, ArrowRight } from 'lucide-react';
import Layout from '../components/Layout';
import { Reveal } from '../components/Reveal';
import { useLanguage } from '../contexts/LanguageContext';

const BuildMine: React.FC = () => {
  const { t } = useLanguage();
  const [activePhase, setActivePhase] = useState(1);

  const phases = [
    {
      id: 1,
      title: t('build_page.phase1_title'),
      text: t('build_page.phase1_text'),
      icon: <Rocket className="w-8 h-8" />,
      color: '#FF5757', // Watermelon Red
    },
    {
      id: 2,
      title: t('build_page.phase2_title'),
      text: t('build_page.phase2_text'),
      icon: <Cpu className="w-8 h-8" />,
      color: '#8A2BE2', // Transition color
    },
    {
      id: 3,
      title: t('build_page.phase3_title'),
      text: t('build_page.phase3_text'),
      icon: <Shield className="w-8 h-8" />,
      color: '#4B0082', // Sunset Purple
    }
  ];

  const activeColor = phases.find(p => p.id === activePhase)?.color || '#FF5757';

  return (
    <Layout>
      <div className="min-h-screen bg-black relative overflow-hidden flex flex-col items-center justify-center py-20">
        
        {/* Dynamic Smoke Background */}
        <motion.div 
          animate={{ 
            backgroundColor: activeColor,
            opacity: [0.1, 0.15, 0.1],
            scale: [1, 1.1, 1],
          }}
          transition={{ 
            backgroundColor: { duration: 1.5, ease: "easeInOut" },
            opacity: { duration: 5, repeat: Infinity, ease: "easeInOut" },
            scale: { duration: 8, repeat: Infinity, ease: "easeInOut" }
          }}
          className="absolute inset-0 blur-[150px] rounded-full -z-10"
          style={{ width: '150%', height: '150%', left: '-25%', top: '-25%' }}
        />

        <div className="max-w-7xl mx-auto px-6 relative z-10 w-full">
          <div className="text-center mb-20">
            <Reveal>
              <h1 className="text-5xl md:text-8xl font-display font-black tracking-tighter text-white mb-6 uppercase">
                {t('build_page.hero_title')}
              </h1>
            </Reveal>
            <Reveal delay={0.2}>
              <p className="text-xl md:text-2xl text-slate-400 font-light tracking-wide">
                {t('build_page.hero_subtitle')}
              </p>
            </Reveal>
          </div>

          {/* Horizontal Phase Cards */}
          <div className="grid lg:grid-cols-3 gap-8 mb-20">
            {phases.map((phase) => (
              <motion.div
                key={phase.id}
                onClick={() => setActivePhase(phase.id)}
                whileHover={{ y: -10 }}
                className={`relative p-10 rounded-[2.5rem] border transition-all duration-500 cursor-pointer group overflow-hidden ${
                  activePhase === phase.id 
                    ? 'bg-white/10 border-white/20 shadow-2xl' 
                    : 'bg-white/5 border-white/5 grayscale opacity-50 hover:opacity-80'
                }`}
              >
                {/* Active Glow */}
                <AnimatePresence>
                  {activePhase === phase.id && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none"
                    />
                  )}
                </AnimatePresence>

                <div className={`mb-8 transition-colors duration-500 ${activePhase === phase.id ? 'text-white' : 'text-white/40'}`}>
                  {phase.icon}
                </div>

                <h3 className={`text-2xl font-display font-black mb-4 tracking-tight transition-colors duration-500 ${activePhase === phase.id ? 'text-white' : 'text-white/40'}`}>
                  {phase.title}
                </h3>
                
                <p className={`text-lg leading-relaxed transition-colors duration-500 ${activePhase === phase.id ? 'text-slate-300' : 'text-slate-500'}`}>
                  {phase.text}
                </p>

                {/* Progress Indicator */}
                <div className="absolute bottom-0 left-0 h-1 bg-white/10 w-full">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: activePhase >= phase.id ? '100%' : '0%' }}
                    className="h-full bg-white/40"
                    transition={{ duration: 0.8, ease: "circOut" }}
                  />
                </div>
              </motion.div>
            ))}
          </div>

          {/* Action Button */}
          <div className="flex justify-center">
            <Reveal delay={0.6}>
              <motion.a
                href="https://calendly.com/vsualdigitalmedia" // Placeholder Calendly
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="group relative px-12 py-6 bg-white text-black rounded-full font-display font-black text-xl uppercase tracking-[0.2em] overflow-hidden shadow-2xl shadow-white/10"
              >
                <span className="relative z-10 flex items-center gap-4">
                  {t('build_page.cta')}
                  <ArrowRight className="group-hover:translate-x-2 transition-transform" />
                </span>
                <motion.div 
                  className="absolute inset-0 bg-[#B32D6A] opacity-0 group-hover:opacity-10 transition-opacity"
                />
              </motion.a>
            </Reveal>
          </div>
        </div>

        {/* Phase Numbers Background */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[40rem] font-black text-white/[0.02] pointer-events-none select-none z-0">
          0{activePhase}
        </div>
      </div>
    </Layout>
  );
};

export default BuildMine;
