import React, { useState, useEffect } from 'react';
import { MapPin } from 'lucide-react';
import Layout from '../components/Layout';
import { Reveal } from '../components/Reveal';
import { useLanguage } from '../contexts/LanguageContext';
import Particles, { initParticlesEngine } from "@tsparticles/react";
import { loadSlim } from "@tsparticles/slim";

const About: React.FC = () => {
  const { t } = useLanguage();

  return (
    <Layout>
      <div className="bg-black min-h-screen relative overflow-hidden">
        <div className="relative py-32 md:py-48 z-10">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <Reveal>
              <h1 className="text-5xl md:text-8xl font-display font-bold text-white mb-12 tracking-tighter">
                {t('about.hero_title_1')} <span className="text-[#B32D6A]">{t('about.hero_title_2')}</span>
              </h1>
              <p className="text-xl md:text-2xl text-slate-300 font-display font-medium mb-8 leading-tight">
                {t('about.hero_subtitle')}
              </p>
            </Reveal>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center mb-32">
            <Reveal>
              <div>
                <h2 className="text-sm font-black uppercase tracking-[0.4em] text-[#B32D6A] mb-8">{t('about.story_badge')}</h2>
                <div className="space-y-8 text-lg md:text-xl text-slate-300 leading-relaxed font-display">
                  <p>
                    {t('about.story_p1')}
                  </p>
                  <p>
                    {t('about.story_p2')}
                  </p>
                </div>
                
                <div className="mt-12 flex items-center gap-4 text-white font-bold uppercase tracking-widest text-xs">
                  <div className="w-10 h-[1px] bg-[#B32D6A]"></div>
                  <span>{t('about.location_badge')}</span>
                </div>
              </div>
            </Reveal>
            <Reveal delay={0.2}>
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-tr from-[#B32D6A] to-purple-500 rounded-2xl opacity-20 blur-2xl"></div>
                <div className="relative rounded-2xl border border-white/10 overflow-hidden shadow-2xl aspect-video">
                  <img 
                    src="https://picsum.photos/seed/hardknocks/1200/800" 
                    alt="Hard Knocks Strategy" 
                    className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
                  />
                  <div className="absolute inset-0 bg-black/40"></div>
                </div>
              </div>
            </Reveal>
          </div>

          {/* Leadership Section */}
          <div className="mt-48 mb-32">
            <Reveal>
              <h2 className="text-4xl md:text-6xl font-display font-bold text-white text-center mb-24 tracking-tighter">{t('about.leadership_title')}</h2>
            </Reveal>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {[
                { 
                  name: 'Sal C.', 
                  role: 'Founder, Strategy Lead + Creative Director', 
                  img: 'https://picsum.photos/seed/sal/600/600' 
                },
                { 
                  name: 'Topon M.', 
                  role: 'Head of AI & Development', 
                  img: 'https://picsum.photos/seed/topon/600/600' 
                },
                { 
                  name: 'Zi', 
                  role: 'Director of Growth + Performance Acquisition', 
                  img: 'https://picsum.photos/seed/zi/600/600' 
                },
              ].map((person, i) => (
                <Reveal key={i} delay={i * 0.1}>
                  <div className="group relative">
                    {/* Smoke Anchor - Background for cards */}
                    <div className="absolute -inset-10 bg-gradient-to-br from-[#FF5757]/5 to-[#4B0082]/5 rounded-full blur-[60px] opacity-0 group-hover:opacity-100 transition-opacity duration-700 -z-10"></div>
                    
                    <div className="relative bg-white/5 border border-white/10 rounded-2xl p-8 text-center backdrop-blur-sm hover:bg-white/10 transition-all duration-500">
                      <div className="w-40 h-40 mx-auto rounded-full overflow-hidden mb-8 border-2 border-white/10 group-hover:border-[#B32D6A] transition-all duration-500">
                        <img src={person.img} alt={person.name} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 scale-110 group-hover:scale-100" />
                      </div>
                      <h3 className="text-2xl font-display font-bold text-white mb-2">{person.name}</h3>
                      <p className="text-[#B32D6A] text-xs font-black uppercase tracking-widest leading-tight">{person.role}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default About;
