import React from 'react';
import { motion } from 'framer-motion';
import { Database, Users, Zap, DollarSign } from 'lucide-react';
import Button from '../components/Button';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import Layout from '../components/Layout';

const Ecosystem: React.FC = () => {
  const { t } = useLanguage();

  return (
    <Layout>
      <div className="bg-white min-h-screen">
         {/* Header */}
         <div className="pt-32 pb-12 text-center max-w-4xl mx-auto px-4">
           <h1 className="text-4xl md:text-6xl font-bold text-black mb-6">{t('ecosystem.title')}</h1>
           <p className="text-xl text-slate-600 mb-8">
             {t('ecosystem.subtitle')}
           </p>
         </div>

         {/* Flow Diagram */}
         <div className="max-w-5xl mx-auto px-4 pb-24">
           <div className="relative">
              {/* Connecting Line */}
              <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-[#B32D6A] via-purple-500 to-purple-800 hidden md:block -translate-x-1/2 opacity-20"></div>

              {/* Steps */}
              <div className="space-y-12 md:space-y-24 relative z-10">
                
                {/* Step 1: Marketing */}
                <motion.div 
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="flex flex-col md:flex-row items-center justify-between gap-8"
                >
                  <div className="md:w-5/12 text-right md:pr-12">
                    <h3 className="text-2xl font-bold text-[#B32D6A] mb-2">{t('ecosystem.step1_title')}</h3>
                    <h4 className="text-xl font-semibold text-black mb-2">{t('ecosystem.step1_sub')}</h4>
                    <p className="text-slate-600">{t('ecosystem.step1_desc')}</p>
                  </div>
                  <div className="w-16 h-16 rounded-full bg-white border-2 border-[#B32D6A] flex items-center justify-center shadow-lg z-10">
                    <Users className="text-[#B32D6A]" />
                  </div>
                  <div className="md:w-5/12 md:pl-12 opacity-50 hidden md:block">
                    <div className="h-1 bg-[#B32D6A]/30 w-24"></div>
                  </div>
                </motion.div>

                {/* Step 2: Dev */}
                <motion.div 
                  initial={{ opacity: 0, x: 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="flex flex-col md:flex-row-reverse items-center justify-between gap-8"
                >
                  <div className="md:w-5/12 text-left md:pl-12">
                    <h3 className="text-2xl font-bold text-purple-500 mb-2">{t('ecosystem.step2_title')}</h3>
                    <h4 className="text-xl font-semibold text-black mb-2">{t('ecosystem.step2_sub')}</h4>
                    <p className="text-slate-600">{t('ecosystem.step2_desc')}</p>
                  </div>
                  <div className="w-16 h-16 rounded-full bg-white border-2 border-purple-500 flex items-center justify-center shadow-lg z-10">
                    <Database className="text-purple-500" />
                  </div>
                  <div className="md:w-5/12 md:pr-12 opacity-50 hidden md:block text-right">
                    <div className="h-1 bg-purple-500/30 w-24 ml-auto"></div>
                  </div>
                </motion.div>

                {/* Step 3: AI */}
                <motion.div 
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="flex flex-col md:flex-row items-center justify-between gap-8"
                >
                  <div className="md:w-5/12 text-right md:pr-12">
                    <h3 className="text-2xl font-bold text-purple-700 mb-2">{t('ecosystem.step3_title')}</h3>
                    <h4 className="text-xl font-semibold text-black mb-2">{t('ecosystem.step3_sub')}</h4>
                    <p className="text-slate-600">{t('ecosystem.step3_desc')}</p>
                  </div>
                  <div className="w-16 h-16 rounded-full bg-white border-2 border-purple-700 flex items-center justify-center shadow-lg z-10">
                    <Zap className="text-purple-700" />
                  </div>
                  <div className="md:w-5/12 md:pl-12 opacity-50 hidden md:block">
                    <div className="h-1 bg-purple-700/30 w-24"></div>
                  </div>
                </motion.div>

                 {/* Step 4: Conversion */}
                 <motion.div 
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="flex flex-col items-center justify-center pt-8"
                >
                  <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#B32D6A] to-purple-600 flex items-center justify-center shadow-2xl mb-6 z-10">
                    <DollarSign className="text-white w-10 h-10" />
                  </div>
                  <h3 className="text-3xl font-bold text-black mb-2">{t('ecosystem.step4_title')}</h3>
                  <p className="text-slate-600 max-w-md text-center">{t('ecosystem.step4_desc')}</p>
                </motion.div>

              </div>
           </div>
         </div>

         <div className="bg-slate-50 py-16 text-center border-t border-slate-100">
           <h2 className="text-2xl font-bold text-black mb-6">{t('cta.desc')}</h2>
           <Link to="/contact">
              <Button size="lg">{t('ecosystem.btn')}</Button>
           </Link>
         </div>
      </div>
    </Layout>
  );
};

export default Ecosystem;
