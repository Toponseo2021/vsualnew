import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus } from 'lucide-react';
import Layout from '../components/Layout';
import { Reveal } from '../components/Reveal';
import { useLanguage } from '../contexts/LanguageContext';

interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}

const FAQItem: React.FC<FAQItemProps> = ({ question, answer, isOpen, onClick }) => {
  return (
    <div 
      className="relative border-b border-white/10 group cursor-pointer"
      onClick={onClick}
    >
      {/* Highlight Background */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{ opacity: 1, scaleX: 1 }}
            exit={{ opacity: 0, scaleX: 0 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="absolute inset-0 bg-gradient-to-r from-[#B32D6A]/20 via-[#4B0082]/15 to-transparent -z-10 origin-left"
          />
        )}
      </AnimatePresence>

      <div className="py-10 flex items-center justify-between gap-8">
        <h3 className={`text-xl md:text-3xl font-display transition-all duration-500 ${isOpen ? 'text-white translate-x-4' : 'text-white/70 group-hover:text-white group-hover:translate-x-2'}`}>
          {question}
        </h3>
        <div className="shrink-0 transition-transform duration-500 group-hover:scale-110">
          {isOpen ? (
            <Minus className="text-[#B32D6A]" size={28} />
          ) : (
            <Plus className="text-white/40 group-hover:text-white" size={28} />
          )}
        </div>
      </div>

      <motion.div
        initial={false}
        animate={{ 
          height: isOpen ? 'auto' : 0,
          opacity: isOpen ? 1 : 0,
          marginBottom: isOpen ? 32 : 0
        }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="overflow-hidden"
      >
        <p className="text-slate-400 text-lg leading-relaxed max-w-3xl">
          {answer}
        </p>
      </motion.div>
    </div>
  );
};

const FAQ: React.FC = () => {
  const { t } = useLanguage();
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const categories = [
    {
      title: t('faq.cat_infra'),
      items: [
        { q: t('faq.q1'), a: t('faq.a1') },
        { q: t('faq.q2'), a: t('faq.a2') },
        { q: t('faq.q3'), a: t('faq.a3') },
        { q: t('faq.q4'), a: t('faq.a4') },
        { q: t('faq.q11'), a: t('faq.a11') },
      ]
    },
    {
      title: t('faq.cat_logic'),
      items: [
        { q: t('faq.q5'), a: t('faq.a5') },
        { q: t('faq.q6'), a: t('faq.a6') },
        { q: t('faq.q7'), a: t('faq.a7') },
      ]
    },
    {
      title: t('faq.cat_growth'),
      items: [
        { q: t('faq.q8'), a: t('faq.a8') },
        { q: t('faq.q9'), a: t('faq.a9') },
        { q: t('faq.q10'), a: t('faq.a10') },
        { q: t('faq.q12'), a: t('faq.a12') },
      ]
    }
  ];

  let itemCounter = 0;

  return (
    <Layout>
      <div className="min-h-screen bg-black relative overflow-hidden pt-32 pb-20">
        <div className="max-w-5xl mx-auto px-4 relative z-10">
          <Reveal>
            <div className="text-center mb-24">
              <h1 className="text-5xl md:text-8xl font-display font-bold text-white tracking-tighter mb-4">
                {t('faq.hero_title')}
              </h1>
              <div className="w-20 h-1 bg-[#B32D6A] mx-auto"></div>
            </div>
          </Reveal>

          <div className="space-y-24">
            {categories.map((category, catIdx) => (
              <div key={catIdx}>
                <Reveal delay={catIdx * 0.1}>
                  <h2 className="text-2xl md:text-4xl font-display font-black uppercase tracking-[0.2em] text-[#B32D6A] mb-12 border-l-8 border-[#B32D6A] pl-8 py-2">
                    {category.title}
                  </h2>
                </Reveal>
                
                <div className="space-y-0">
                  {category.items.map((item, itemIdx) => {
                    const currentIndex = itemCounter++;
                    return (
                      <Reveal key={itemIdx} delay={0.2 + itemIdx * 0.05}>
                        <FAQItem
                          question={item.q}
                          answer={item.a}
                          isOpen={openIndex === currentIndex}
                          onClick={() => {
                            setOpenIndex(openIndex === currentIndex ? null : currentIndex);
                          }}
                        />
                      </Reveal>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default FAQ;
