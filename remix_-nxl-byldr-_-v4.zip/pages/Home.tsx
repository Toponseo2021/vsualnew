import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, CheckCircle2, Globe, Zap, ShieldCheck, Award, Star, Search, Palette, Code, Terminal } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Reveal } from '../components/Reveal';
import Button from '../components/Button';
import { LogoReveal } from '../components/LogoReveal';
import { HeroLogo } from '../components/HeroLogo';
import Layout from '../components/Layout';
import { useLanguage } from '../contexts/LanguageContext';

const Home: React.FC = () => {
  const { t } = useLanguage();
  const [showContent, setShowContent] = useState(false);
  const [videoEnded, setVideoEnded] = useState(false);
  const [videoOpacity, setVideoOpacity] = useState(1);
  const [videoDisplay, setVideoDisplay] = useState('block');
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    // Loading screen duration
    const timer = setTimeout(() => setShowContent(true), 3000);
    return () => clearTimeout(timer);
  }, []);

  const handleVideoEnd = () => {
    setVideoOpacity(0);
    setTimeout(() => {
      setVideoDisplay('none');
      setVideoEnded(true);
    }, 1500); // 1.5s fade out
  };

  return (
    <Layout fluidInteractive={videoEnded}>
      <div className="overflow-hidden">
        
        {/* Loading Screen */}
        {!showContent && (
          <div className="fixed inset-0 z-[1000] bg-black">
            <LogoReveal />
          </div>
        )}

        {/* Video Layer */}
        {showContent && (
          <div 
            className="fixed inset-0 w-full h-full z-10 pointer-events-none overflow-hidden"
            style={{ 
              opacity: videoOpacity, 
              display: videoDisplay,
              transition: 'opacity 1.5s ease-in-out'
            }}
          >
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              onEnded={handleVideoEnd}
              className="w-full h-full object-cover"
            >
              <source src="https://assets.mixkit.co/videos/preview/mixkit-abstract-flowing-smoke-28-large.mp4" type="video/mp4" />
            </video>
          </div>
        )}

        {/* Section 1: Hero - Black Background */}
        <section className="min-h-screen bg-black text-white pt-32 pb-20 flex flex-col justify-center relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-[20] flex flex-col items-center justify-center text-center h-full">
            <Reveal>
              <div className="w-full mb-8">
                <HeroLogo />
              </div>
              <p className="text-sm md:text-base font-display font-medium tracking-[0.5em] uppercase text-white mb-12 opacity-80">
                {t('home.hero_subtitle')}
              </p>
            </Reveal>
          </div>

          <div className="absolute bottom-[10%] left-1/2 -translate-x-1/2 z-[30]">
            <Reveal delay={0.5}>
              <Link to="/build">
                <button className="px-10 py-4 border-2 border-white bg-black/70 backdrop-blur-[5px] text-white font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-all duration-300 group">
                  {t('home.hero_cta')} <span className="inline-block group-hover:translate-x-1 transition-transform ml-2">→</span>
                </button>
              </Link>
            </Reveal>
          </div>
        </section>

      {/* Section 2: What We Do Best - White Background */}
      <section className="py-32 bg-white text-black relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-20">
            <Reveal>
              <div className="flex items-center gap-2 mb-6">
                <div className="w-2 h-2 rounded-full bg-[#B32D6A]"></div>
                <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-slate-500">{t('home.what_we_do_badge')}</span>
              </div>
              <h2 className="text-4xl md:text-6xl font-display font-bold mb-8 leading-tight">
                {t('home.what_we_do_title')}
              </h2>
            </Reveal>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { 
                title: t('home.service_web_design_title'), 
                desc: t('home.service_web_design_desc'),
                icon: <Palette className="text-[#B32D6A]" />
              },
              { 
                title: t('home.service_web_dev_title'), 
                desc: t('home.service_web_dev_desc'),
                icon: <Code className="text-[#B32D6A]" />
              },
              { 
                title: t('home.service_ai_title'), 
                desc: t('home.service_ai_desc'),
                icon: <Terminal className="text-[#B32D6A]" />
              },
              { 
                title: t('home.service_branding_title'), 
                desc: t('home.service_branding_desc'),
                icon: <Zap className="text-[#B32D6A]" />
              },
              { 
                title: t('home.service_marketing_title'), 
                desc: t('home.service_marketing_desc'),
                icon: <Globe className="text-[#B32D6A]" />
              },
              { 
                title: t('home.service_consultation_title'), 
                desc: t('home.service_consultation_desc'),
                icon: <Search className="text-[#B32D6A]" />
              }
            ].map((service, i) => (
              <Reveal key={i} delay={i * 0.1}>
                <div className="p-8 rounded-2xl bg-slate-50 border border-slate-200 hover:border-[#B32D6A]/50 transition-all group h-full">
                  <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center mb-6 group-hover:bg-[#B32D6A]/20 transition-colors">
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-bold mb-4">{service.title}</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">{service.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Section 3: Our Process - White Background */}
      <section className="py-32 bg-white text-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-24">
            <Reveal>
              <h2 className="text-4xl md:text-6xl font-display font-bold mb-6">{t('home.process_title')}</h2>
              <p className="text-slate-600 max-w-2xl mx-auto">{t('home.process_subtitle')}</p>
            </Reveal>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {[
              { 
                phase: t('home.process_step1_phase'), 
                title: t('home.process_step1_title'), 
                items: ['Discovery', 'Wireframing', 'Content Strategy'],
                desc: t('home.process_step1_desc')
              },
              { 
                phase: t('home.process_step2_phase'), 
                title: t('home.process_step2_title'), 
                items: ['Concepts', 'Site Design', 'Interactivity'],
                desc: t('home.process_step2_desc')
              },
              { 
                phase: t('home.process_step3_phase'), 
                title: t('home.process_step3_title'), 
                items: ['Custom Blocks', 'Functionality', 'CMS'],
                desc: t('home.process_step3_desc')
              },
              { 
                phase: t('home.process_step4_phase'), 
                title: t('home.process_step4_title'), 
                items: ['QA Testing', 'Compliance', 'SEO'],
                desc: t('home.process_step4_desc')
              }
            ].map((step, i) => (
              <Reveal key={i} delay={i * 0.1}>
                <div className="relative">
                  <div className="text-[10px] font-black uppercase tracking-widest text-[#B32D6A] mb-4">{step.phase}</div>
                  <h3 className="text-2xl font-bold mb-6">{step.title}</h3>
                  <div className="flex flex-wrap gap-2 mb-6">
                    {step.items.map((item, idx) => (
                      <span key={idx} className="px-3 py-1 bg-slate-100 rounded-full text-[10px] font-bold uppercase tracking-wider text-slate-500">{item}</span>
                    ))}
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">{step.desc}</p>
                  {i < 3 && <div className="hidden lg:block absolute top-1/2 -right-6 w-12 h-[1px] bg-slate-200"></div>}
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Section 4: What Makes Us Different - White Background */}
      <section className="py-32 bg-white text-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div>
              <Reveal>
                <h2 className="text-4xl md:text-6xl font-display font-bold mb-12 leading-tight">
                  {t('home.different_title')}
                </h2>
                <div className="space-y-12">
                  {[
                    { 
                      title: t('home.different_card1_title'), 
                      desc: t('home.different_card1_desc'),
                      icon: <Star className="text-[#B32D6A]" />
                    },
                    { 
                      title: t('home.different_card2_title'), 
                      desc: t('home.different_card2_desc'),
                      icon: <Award className="text-[#B32D6A]" />
                    },
                    { 
                      title: t('home.different_card3_title'), 
                      desc: t('home.different_card3_desc'),
                      icon: <CheckCircle2 className="text-[#B32D6A]" />
                    },
                    { 
                      title: t('home.different_card4_title'), 
                      desc: t('home.different_card4_desc'),
                      icon: <ShieldCheck className="text-[#B32D6A]" />
                    }
                  ].map((item, i) => (
                    <div key={i} className="flex gap-6">
                      <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center shrink-0">
                        {item.icon}
                      </div>
                      <div>
                        <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                        <p className="text-slate-600 text-sm leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Reveal>
            </div>
            
            <div className="relative">
              <Reveal delay={0.3}>
                <div className="aspect-square rounded-full border border-slate-200 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-[#B32D6A]/10 to-transparent opacity-50"></div>
                  <div className="text-center z-10 p-12">
                    <div className="text-8xl font-display font-bold text-black mb-4">100%</div>
                    <div className="text-sm font-bold uppercase tracking-[0.3em] text-[#B32D6A]">Bespoke Logic</div>
                    <p className="mt-6 text-slate-600 max-w-xs mx-auto">Every line of code and pixel is crafted in our LA and OC studios.</p>
                  </div>
                  
                  {/* Decorative Circles */}
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                    className="absolute inset-0 border border-dashed border-slate-300 rounded-full scale-90"
                  ></motion.div>
                </div>
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* Section 5: Final CTA - Black Background */}
      <section className="py-40 bg-black text-white text-center relative overflow-hidden z-[10]">
        <div className="max-w-4xl mx-auto px-4 relative z-10">
          <Reveal>
            <h2 className="text-6xl md:text-9xl font-display font-bold mb-12 tracking-tighter leading-[0.8]">
              {t('home.cta_title_1')}<br />
              <span className="text-[#B32D6A]">{t('home.cta_title_2')}</span>
            </h2>
            <Link to="/build">
              <button className="rounded-full px-12 py-6 text-xl bg-black/70 backdrop-blur-[5px] text-white hover:bg-white hover:text-black border border-white shadow-2xl transition-all font-bold">
                {t('home.cta_btn')}
              </button>
            </Link>
          </Reveal>
        </div>
        
        {/* Decorative Background Elements */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#B32D6A]/5 rounded-full blur-[120px] -z-0"></div>
      </section>

    </div>
    </Layout>
  );
};

export default Home;
