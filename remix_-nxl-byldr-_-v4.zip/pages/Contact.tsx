import React, { useState } from 'react';
import { Mail, Phone, CheckCircle2, AlertCircle, Loader2, ArrowRight, Globe, Share2, UserCircle2, Lock, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import Layout from '../components/Layout';

const Contact: React.FC = () => {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const [step, setStep] = useState(1); // 1: Blueprint, 2: Sync, 3: Login
  const [syncStatus, setSyncStatus] = useState(0); // 0-3 for the 4 status messages
  const [syncProgress, setSyncProgress] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showBudgetReminder, setShowBudgetReminder] = useState(false);
  const [isTypingSensitive, setIsTypingSensitive] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    mobile: '',
    brandIdentity: '',
    digitalFootprint: '',
    targetPersona: '',
    password: '',
    hasBudget: false
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setFormData({ 
      ...formData, 
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value 
    });
    
    if (name === 'hasBudget' && (e.target as HTMLInputElement).checked) {
      setShowBudgetReminder(false);
    }
  };

  const handleSensitiveFocus = () => setIsTypingSensitive(true);
  const handleSensitiveBlur = () => setIsTypingSensitive(false);

  const statuses = [
    t('contact.sync_status1'),
    t('contact.sync_status2'),
    t('contact.sync_status3'),
    t('contact.sync_status4')
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.hasBudget) {
      setShowBudgetReminder(true);
      return;
    }

    setIsSubmitting(true);
    setStep(2);

    // Simulate the sync process with 3-second intervals
    for (let i = 0; i < statuses.length; i++) {
      setSyncStatus(i);
      // Update progress bar smoothly
      const targetProgress = ((i + 1) / statuses.length) * 100;
      const startProgress = syncProgress;
      const duration = 3000;
      const startTime = Date.now();

      await new Promise<void>(resolve => {
        const animate = () => {
          const now = Date.now();
          const elapsed = now - startTime;
          const progress = Math.min(elapsed / duration, 1);
          setSyncProgress(startProgress + (targetProgress - startProgress) * progress);
          
          if (progress < 1) {
            requestAnimationFrame(animate);
          } else {
            resolve();
          }
        };
        requestAnimationFrame(animate);
      });
    }
    
    setIsSubmitting(false);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/portal');
  };

  return (
    <Layout>
      <div className="bg-white min-h-screen pb-24 font-sans selection:bg-[#B32D6A]/10 pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Progress Bar */}
          <div className="max-w-3xl mx-auto mb-16 pt-12">
            <div className="flex justify-between items-center relative">
              <div className="absolute top-1/2 left-0 w-full h-0.5 bg-neutral-900 -translate-y-1/2 z-0"></div>
              <motion.div 
                className="absolute top-1/2 left-0 h-0.5 bg-[#B32D6A] -translate-y-1/2 z-0"
                initial={{ width: '0%' }}
                animate={{ width: step === 1 ? '0%' : step === 2 ? '50%' : '100%' }}
              ></motion.div>
              
              {[
                { id: 1, label: t('contact.step1_label') },
                { id: 2, label: t('contact.step2_label') },
                { id: 3, label: t('contact.step3_label') }
              ].map((s) => (
                <div key={s.id} className="relative z-10 flex flex-col items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-colors duration-500 ${
                    step >= s.id ? 'bg-[#B32D6A] border-[#B32D6A] text-white' : 'bg-white border-slate-200 text-slate-400'
                  }`}>
                    {step > s.id ? <CheckCircle2 size={20} /> : <span className="text-xs font-bold">{s.id}</span>}
                  </div>
                  <span className={`text-[10px] uppercase tracking-widest mt-3 font-bold ${step >= s.id ? 'text-[#B32D6A]' : 'text-slate-400'}`}>
                    Step {s.id}: {s.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
            {/* Info */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h1 className="text-5xl md:text-7xl font-display font-black text-black mb-8 tracking-tighter uppercase leading-[0.9]">
                {t('contact.hero_title').split(' ')[0]} <br />
                <span className="text-[#B32D6A]">{t('contact.hero_title').split(' ')[1]}</span>
              </h1>
              <p className="text-slate-600 text-xl mb-12 leading-relaxed max-w-md">
                {t('contact.hero_subtitle')}
              </p>

              <div className="space-y-8">
                <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl">
                  <h3 className="text-[#B32D6A] font-bold uppercase tracking-widest text-xs mb-4">{t('contact.kaizen_title')}</h3>
                  <ul className="space-y-4 text-sm text-slate-600">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-[#B32D6A] shrink-0 mt-0.5" />
                      <span>{t('contact.kaizen_item1')}</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-[#B32D6A] shrink-0 mt-0.5" />
                      <span>{t('contact.kaizen_item2')}</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-[#B32D6A] shrink-0 mt-0.5" />
                      <span>{t('contact.kaizen_item3')}</span>
                    </li>
                  </ul>
                </div>

                {/* Infrastructure Support Sidebar */}
                <div className="p-6 border-l-2 border-slate-100 space-y-8">
                  <h3 className="text-black font-display font-black uppercase tracking-widest text-[10px]">{t('contact.infra_title')}</h3>
                  
                  <div className="space-y-2">
                    <h4 className="text-black text-xs font-bold uppercase tracking-tight">{t('contact.infra_q1')}</h4>
                    <p className="text-slate-500 text-xs leading-relaxed">
                      {t('contact.infra_a1')}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-black text-xs font-bold uppercase tracking-tight">{t('contact.infra_q2')}</h4>
                    <p className="text-slate-500 text-xs leading-relaxed">
                      {t('contact.infra_a2').replace(t('contact.infra_call'), '').replace(t('contact.infra_ai'), '')}
                      <span className="text-[#B32D6A] cursor-pointer hover:underline">{t('contact.infra_call')}</span>
                      {' ' + (language === 'en' ? 'or engage the' : 'o interactúe con el') + ' '}
                      <span className="text-[#B32D6A] cursor-pointer hover:underline">{t('contact.infra_ai')}</span>.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-6 text-slate-400">
                  <div className="flex items-center gap-2">
                    <Mail size={16} />
                    <span className="text-xs font-mono">ops@nxlbyldr.com</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Globe size={16} />
                    <span className="text-xs font-mono">USA BASED</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Form Container */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-50 border border-slate-200 p-8 md:p-12 rounded-3xl shadow-xl relative overflow-hidden"
            >
              <AnimatePresence mode="wait">
                {step === 1 && (
                  <motion.div
                    key="step1"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <div className="flex justify-between items-center mb-8">
                      <h2 className="text-2xl font-display font-bold text-black uppercase tracking-tight">{t('contact.form_title')}</h2>
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full transition-all duration-300 ${isTypingSensitive ? 'bg-[#B32D6A] shadow-[0_0_10px_#B32D6A]' : 'bg-green-500'}`}></div>
                        <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400">
                          {isTypingSensitive ? t('contact.form_secure') : t('contact.form_ready')}
                        </span>
                      </div>
                    </div>
                    <form onSubmit={handleSubmit} className="space-y-8">
                      
                      {/* Top Section: Command Center Credentials */}
                      <div className="space-y-4">
                        <h3 className="text-[10px] uppercase tracking-[0.3em] font-black text-[#B32D6A]">{t('contact.credentials_title')}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="relative">
                            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#B32D6A]/70" size={18} />
                            <input 
                              type="email" 
                              name="email"
                              value={formData.email}
                              onChange={handleChange}
                              className="w-full bg-white border border-slate-200 rounded-xl pl-12 pr-4 py-4 text-black focus:outline-none focus:border-[#B32D6A] transition-colors placeholder-slate-300 text-base"
                              placeholder={t('contact.placeholder_email')}
                              required
                            />
                          </div>
                          <div className="relative">
                            <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-[#B32D6A]/70" size={18} />
                            <input 
                              type="tel" 
                              name="mobile"
                              value={formData.mobile}
                              onChange={handleChange}
                              className="w-full bg-white border border-slate-200 rounded-xl pl-12 pr-4 py-4 text-black focus:outline-none focus:border-[#B32D6A] transition-colors placeholder-slate-300 text-base"
                              placeholder={t('contact.placeholder_mobile')}
                              required
                            />
                          </div>
                        </div>
                          <div className="relative group">
                            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#B32D6A]/70" size={18} />
                            <input 
                              type="password" 
                              name="password"
                              value={formData.password}
                              onChange={handleChange}
                              onFocus={handleSensitiveFocus}
                              onBlur={handleSensitiveBlur}
                              className="w-full bg-white border border-slate-200 rounded-xl pl-12 pr-4 py-4 text-black focus:outline-none focus:border-[#B32D6A] transition-colors placeholder-slate-300 text-base"
                              placeholder={t('contact.placeholder_password')}
                              required
                            />
                            {/* Ephemeral Access Tooltip */}
                            <div className="absolute bottom-full left-0 mb-2 w-64 p-3 bg-white border border-slate-200 rounded-lg shadow-2xl opacity-0 invisible group-focus-within:opacity-100 group-focus-within:visible transition-all z-50">
                              <p className="text-[10px] text-slate-500 leading-relaxed">
                                {t('contact.password_tooltip')}
                              </p>
                              <div className="absolute top-full left-6 w-2 h-2 bg-white border-r border-b border-slate-200 rotate-45 -translate-y-1"></div>
                            </div>
                          </div>
                      </div>

                      {/* Middle Section: Ecosystem Specs */}
                      <div className="space-y-4">
                        <h3 className="text-[10px] uppercase tracking-[0.3em] font-black text-[#B32D6A]">{t('contact.specs_title')}</h3>
                        <div className="space-y-4">
                          <div className="relative">
                            <Globe className="absolute left-4 top-1/2 -translate-y-1/2 text-[#B32D6A]/70" size={18} />
                            <input 
                              type="text" 
                              name="brandIdentity"
                              value={formData.brandIdentity}
                              onChange={handleChange}
                              className="w-full bg-white border border-slate-200 rounded-xl pl-12 pr-4 py-4 text-black focus:outline-none focus:border-[#B32D6A] transition-colors placeholder-slate-300 text-base"
                              placeholder={t('contact.placeholder_brand')}
                              required
                            />
                          </div>
                          <div className="relative">
                            <Share2 className="absolute left-4 top-1/2 -translate-y-1/2 text-[#B32D6A]/70" size={18} />
                            <input 
                              type="url" 
                              name="digitalFootprint"
                              value={formData.digitalFootprint}
                              onChange={handleChange}
                              className="w-full bg-white border border-slate-200 rounded-xl pl-12 pr-4 py-4 text-black focus:outline-none focus:border-[#B32D6A] transition-colors placeholder-slate-300 text-base"
                              placeholder={t('contact.placeholder_url')}
                              required
                            />
                          </div>
                          <div className="relative">
                            <UserCircle2 className="absolute left-4 top-6 text-[#B32D6A]/70" size={18} />
                            <textarea 
                              name="targetPersona"
                              value={formData.targetPersona}
                              onChange={handleChange}
                              rows={3}
                              className="w-full bg-white border border-slate-200 rounded-xl pl-12 pr-4 py-4 text-black focus:outline-none focus:border-[#B32D6A] transition-colors placeholder-slate-300 text-base resize-none"
                              placeholder={t('contact.placeholder_persona')}
                              required
                            />
                          </div>
                        </div>
                      </div>

                      {/* Bottom Section: Gateway Checkbox */}
                      <div className="pt-4 space-y-6">
                        <label className="flex items-start gap-4 cursor-pointer group">
                          <div className="relative flex items-center mt-1">
                            <input 
                              type="checkbox" 
                              name="hasBudget"
                              checked={formData.hasBudget}
                              onChange={handleChange}
                              className="peer sr-only"
                            />
                            <div className="w-6 h-6 border-2 border-slate-200 rounded-md bg-white peer-checked:bg-[#B32D6A] peer-checked:border-[#B32D6A] transition-all"></div>
                            <CheckCircle2 className="absolute inset-0 m-auto text-white opacity-0 peer-checked:opacity-100 transition-opacity" size={16} />
                          </div>
                          <span className="text-sm text-black font-bold group-hover:text-[#B32D6A] transition-colors">
                            {t('contact.budget_confirm')}
                          </span>
                        </label>

                        <AnimatePresence>
                          {showBudgetReminder && (
                            <motion.div 
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              className="p-4 bg-pink-950/30 border border-pink-900/50 rounded-xl flex items-start gap-3 text-pink-200 text-xs leading-relaxed"
                            >
                              <AlertCircle size={16} className="shrink-0 mt-0.5" />
                              <p>{t('contact.budget_reminder')}</p>
                            </motion.div>
                          )}
                        </AnimatePresence>

                        <button 
                          type="submit"
                          disabled={isSubmitting}
                          className="w-full bg-white text-black font-black py-5 rounded-xl hover:bg-[#B32D6A] hover:text-white transition-all duration-300 uppercase tracking-[0.2em] text-xs flex items-center justify-center gap-3 shadow-lg shadow-white/10"
                        >
                          {isSubmitting ? <Loader2 className="animate-spin" /> : t('contact.btn_initialize')}
                        </button>
                      </div>
                    </form>
                  </motion.div>
                )}

                {step === 2 && (
                  <motion.div
                    key="step2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center justify-center py-24 text-center bg-white min-h-[400px]"
                  >
                    <div className="mb-12 w-full max-w-md">
                      <h2 className="text-2xl font-display font-black text-black mb-2 uppercase tracking-tighter">
                        {t('contact.sync_title')}
                      </h2>
                      <p className="text-slate-400 text-sm uppercase tracking-widest mb-12 leading-relaxed">
                        {t('contact.sync_subtitle')}
                      </p>
                      
                      {/* Pink Loading Bar */}
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden mb-8">
                        <motion.div 
                          className="h-full bg-[#B32D6A]"
                          initial={{ width: '0%' }}
                          animate={{ width: `${syncProgress}%` }}
                          transition={{ duration: 0.1 }}
                        />
                      </div>

                      <div className="h-12 flex items-center justify-center">
                        <AnimatePresence mode="wait">
                          <motion.p 
                            key={syncStatus}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            className={`text-lg font-bold uppercase tracking-tight ${syncStatus === 3 ? 'text-[#B32D6A]' : 'text-black'}`}
                          >
                            {statuses[syncStatus]}
                          </motion.p>
                        </AnimatePresence>
                      </div>
                    </div>

                    {syncStatus === 3 && (
                      <motion.button
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        onClick={() => setStep(3)}
                        className="mt-8 bg-black text-white font-black py-6 px-12 rounded-xl hover:bg-[#B32D6A] hover:text-white transition-all duration-300 uppercase tracking-[0.3em] text-lg flex items-center gap-4 shadow-2xl shadow-black/10"
                      >
                        {t('contact.btn_enter')} <ArrowRight size={24} />
                      </motion.button>
                    )}
                  </motion.div>
                )}

                {step === 3 && (
                  <motion.div
                    key="step3"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="py-6"
                  >
                    <div className="text-center mb-10">
                      <div className="w-16 h-16 bg-[#B32D6A]/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-[#B32D6A]/20">
                        <ShieldCheck size={32} className="text-[#B32D6A]" />
                      </div>
                      <h2 className="text-3xl font-display font-black text-black mb-2 uppercase tracking-tighter">{t('contact.access_title')}</h2>
                      <p className="text-slate-500 text-xs uppercase tracking-widest font-bold">{t('contact.access_subtitle')}</p>
                    </div>

                    <form onSubmit={handleLogin} className="space-y-6">
                      <div className="relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#B32D6A]/70" size={18} />
                        <input 
                          type="email" 
                          value={formData.email}
                          disabled
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-4 py-4 text-slate-400 focus:outline-none cursor-not-allowed text-base"
                          placeholder={t('contact.placeholder_email')}
                        />
                      </div>
                      <div className="relative">
                        <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#B32D6A]/70" size={18} />
                        <input 
                          type="password" 
                          className="w-full bg-white border border-slate-200 rounded-xl pl-12 pr-4 py-4 text-black focus:outline-none focus:border-[#B32D6A] transition-colors placeholder-slate-300 text-base"
                          placeholder={t('contact.placeholder_enter_password')}
                          required
                          autoFocus
                        />
                      </div>
                      <button 
                        type="submit"
                        className="w-full bg-[#B32D6A] text-white font-black py-5 rounded-xl hover:bg-[#D0007A] transition-all duration-300 uppercase tracking-[0.2em] text-xs flex items-center justify-center gap-3 shadow-lg shadow-[#B32D6A]/20"
                      >
                        {t('contact.btn_enter')} <ArrowRight size={16} />
                      </button>
                      <div className="text-center">
                        <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">
                          {t('contact.kaizen_protocol')}
                        </p>
                      </div>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Contact;
