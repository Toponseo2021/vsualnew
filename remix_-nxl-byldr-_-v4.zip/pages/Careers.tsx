import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/Layout';
import { Reveal } from '../components/Reveal';
import { useLanguage } from '../contexts/LanguageContext';
import Particles, { initParticlesEngine } from "@tsparticles/react";
import { loadSlim } from "@tsparticles/slim";
import { Link } from 'react-router-dom';

const Careers: React.FC = () => {
  const { t } = useLanguage();

  return (
    <Layout>
      <div className="min-h-screen bg-black relative overflow-hidden flex flex-col justify-center">
        {/* Content Layer */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-[20] py-32">
          <div className="text-center mb-24">
            <Reveal>
              <h1 className="text-5xl md:text-8xl font-display font-bold text-white mb-8 tracking-tighter leading-none">
                <span className="relative inline-block">
                  {t('careers.hero_title_1')}
                  {/* Glass-morphism blur effect behind text */}
                  <div className="absolute -inset-4 bg-white/5 backdrop-blur-xl rounded-2xl -z-10"></div>
                </span>
                <br />
                <span className="text-[#B32D6A]">{t('careers.hero_title_2')}</span>
              </h1>
              <div className="max-w-2xl mx-auto mt-12">
                <p className="text-lg md:text-xl text-slate-300 font-display font-medium leading-relaxed">
                  {t('careers.hero_subtitle')}
                </p>
              </div>
            </Reveal>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Card A */}
            <Reveal delay={0.2}>
              <Link to="/apply" className="group relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-[#FF5757] to-[#4B0082] rounded-2xl blur opacity-20 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl p-10 h-full flex flex-col justify-between hover:bg-black/60 transition-all">
                  <div>
                    <h3 className="text-2xl font-display font-bold text-white mb-4 tracking-tight">{t('careers.intern_sales_title')}</h3>
                    <p className="text-slate-400 font-display italic text-lg leading-relaxed">
                      {t('careers.intern_sales_quote')}
                    </p>
                  </div>
                  <div className="mt-12">
                    <div className="text-[10px] font-black uppercase tracking-[0.3em] text-[#B32D6A]">{t('careers.apply_now')}</div>
                  </div>
                </div>
              </Link>
            </Reveal>

            {/* Card B */}
            <Reveal delay={0.4}>
              <Link to="/apply" className="group relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-[#4B0082] to-[#FF5757] rounded-2xl blur opacity-20 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl p-10 h-full flex flex-col justify-between hover:bg-black/60 transition-all">
                  <div>
                    <h3 className="text-2xl font-display font-bold text-white mb-4 tracking-tight">{t('careers.intern_marketing_title')}</h3>
                    <p className="text-slate-400 font-display italic text-lg leading-relaxed">
                      {t('careers.intern_marketing_quote')}
                    </p>
                  </div>
                  <div className="mt-12">
                    <div className="text-[10px] font-black uppercase tracking-[0.3em] text-[#B32D6A]">{t('careers.apply_now')}</div>
                  </div>
                </div>
              </Link>
            </Reveal>
          </div>

          <div className="mt-32 text-center">
            <Reveal delay={0.6}>
              <Link to="/contact">
                <button className="rounded-full px-12 py-6 text-xl bg-[#B32D6A] text-white hover:bg-white hover:text-black border-none shadow-2xl transition-all font-bold uppercase tracking-widest">
                  {t('careers.cta')}
                </button>
              </Link>
            </Reveal>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Careers;
