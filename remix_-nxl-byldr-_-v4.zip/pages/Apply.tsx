import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/Layout';
import { Reveal } from '../components/Reveal';
import { useLanguage } from '../contexts/LanguageContext';
import Particles, { initParticlesEngine } from "@tsparticles/react";
import { loadSlim } from "@tsparticles/slim";
import { Upload, CheckCircle2 } from 'lucide-react';

const Apply: React.FC = () => {
  const { t } = useLanguage();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFileName(e.target.files[0].name);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-black relative overflow-hidden pt-32 pb-20">
        <div className="max-w-3xl mx-auto px-4 relative z-10">
          <Reveal>
            <div className="text-center mb-16">
              <h1 className="text-4xl md:text-6xl font-display font-bold text-white tracking-tighter mb-4">
                {t('apply.hero_title')}
              </h1>
              <div className="w-20 h-1 bg-[#B32D6A] mx-auto"></div>
            </div>
          </Reveal>

          {!isSubmitted ? (
            <Reveal delay={0.2}>
              <div className="bg-black/40 backdrop-blur-2xl border border-white/10 rounded-2xl p-8 md:p-12 shadow-2xl">
                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="space-y-6">
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-slate-500 mb-2">{t('apply.label_name')}</label>
                      <input 
                        type="text" 
                        required
                        className="w-full bg-transparent border-b border-white/20 py-4 text-white focus:border-[#B32D6A] outline-none transition-colors font-display text-lg"
                        placeholder={t('apply.placeholder_name')}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-slate-500 mb-2">{t('apply.label_email')}</label>
                      <input 
                        type="email" 
                        required
                        className="w-full bg-transparent border-b border-white/20 py-4 text-white focus:border-[#B32D6A] outline-none transition-colors font-display text-lg"
                        placeholder={t('apply.placeholder_email')}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-slate-500 mb-2">{t('apply.label_story')}</label>
                      <textarea 
                        required
                        rows={4}
                        className="w-full bg-transparent border border-white/10 rounded-xl p-4 text-white focus:border-[#B32D6A] outline-none transition-colors font-display text-lg resize-none"
                        placeholder={t('apply.placeholder_story')}
                      />
                    </div>
                  </div>

                  <div className="flex flex-col md:flex-row gap-6 items-center justify-between pt-4">
                    <div className="relative w-full md:w-auto">
                      <input 
                        type="file" 
                        id="resume-upload" 
                        className="hidden" 
                        onChange={handleFileChange}
                        accept=".pdf,.doc,.docx"
                      />
                      <label 
                        htmlFor="resume-upload"
                        className="flex items-center justify-center gap-3 px-8 py-4 border border-white rounded-full text-white text-xs font-black uppercase tracking-widest cursor-pointer hover:border-[#B32D6A] hover:text-[#B32D6A] transition-all w-full md:w-auto"
                      >
                        <Upload size={16} />
                        {fileName ? fileName : t('apply.upload_resume')}
                      </label>
                    </div>

                    <button 
                      type="submit"
                      className="w-full md:w-auto px-12 py-4 bg-white text-black rounded-full text-xs font-black uppercase tracking-widest hover:bg-[#B32D6A] hover:text-white transition-all"
                    >
                      {t('apply.submit')}
                    </button>
                  </div>
                </form>
              </div>
            </Reveal>
          ) : (
            <Reveal>
              <div className="bg-black/40 backdrop-blur-2xl border border-white/10 rounded-2xl p-12 text-center shadow-2xl">
                <div className="w-20 h-20 bg-[#B32D6A]/20 rounded-full flex items-center justify-center mx-auto mb-8">
                  <CheckCircle2 className="text-[#B32D6A]" size={40} />
                </div>
                <h2 className="text-3xl font-display font-bold text-white mb-4 text-white">{t('apply.success_title')}</h2>
                <p className="text-slate-400 font-display mb-8">{t('apply.success_subtitle')}</p>
                <div className="w-full h-[1px] bg-white/10 mb-8"></div>
                <p className="text-xs font-black uppercase tracking-[0.3em] text-[#B32D6A] mb-8">{t('apply.next_step')}</p>
                
                {/* Calendly Widget Placeholder */}
                <div className="w-full min-h-[400px] bg-white/5 rounded-xl border border-white/10 flex items-center justify-center overflow-hidden">
                  <div className="text-center p-8">
                    <p className="text-slate-500 text-sm font-mono mb-4 uppercase tracking-widest">[ CALENDLY SYSTEM INITIALIZING ]</p>
                    {/* In a real app, you'd use the Calendly embed code here */}
                    <div className="calendly-inline-widget" data-url="https://calendly.com/nxl-byldr/intake" style={{ minWidth: '320px', height: '630px' }}></div>
                  </div>
                </div>
              </div>
            </Reveal>
          )}

          {/* Calendly Integration Section (Visible after form or as a separate step) */}
          {!isSubmitted && (
            <div className="mt-20">
              <Reveal delay={0.4}>
                <div className="text-center mb-12">
                  <h3 className="text-sm font-black uppercase tracking-[0.4em] text-slate-500">{t('apply.schedule_directly')}</h3>
                </div>
                <div className="w-full min-h-[600px] bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 overflow-hidden">
                  {/* Calendly Embed with dark theme simulation */}
                  <iframe 
                    src="https://calendly.com/nxl-byldr/intake?hide_event_type_details=1&hide_gdpr_banner=1&background_color=000000&text_color=ffffff&primary_color=b32d6a" 
                    width="100%" 
                    height="600" 
                    frameBorder="0"
                    title="Calendly Briefing"
                  ></iframe>
                </div>
              </Reveal>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default Apply;
