import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LayoutDashboard, Users, Zap, BarChart3, LogOut, Bell, X } from 'lucide-react';
import { HeroLogo } from '../components/HeroLogo';
import { Reveal } from '../components/Reveal';
import { useLanguage } from '../contexts/LanguageContext';

import Layout from '../components/Layout';

const ClientPortal: React.FC = () => {
  const { t } = useLanguage();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggedIn(true);
    setShowWelcome(true);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-black text-white font-sans selection:bg-[#B32D6A]/20 pt-32">
        <AnimatePresence mode="wait">
          {!isLoggedIn ? (
            <motion.div 
              key="login"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden py-24"
            >
            <div className="relative z-[20] w-full max-w-4xl px-6 text-center py-20">
              <Reveal>
                <div className="w-full mb-6 md:mb-10">
                  <HeroLogo />
                </div>
                <p className="text-sm md:text-base font-display font-medium tracking-[0.5em] uppercase text-white mb-10 md:mb-14 opacity-80">
                  {t('portal.hero_subtitle')}
                </p>
                
                <div className="max-w-md mx-auto bg-white/5 backdrop-blur-xl p-8 rounded-3xl border border-white/10 mb-12">
                  <form onSubmit={handleLogin} className="space-y-6">
                    <div className="text-left">
                      <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-2 ml-1">{t('portal.label_email')}</label>
                      <input 
                        type="email" 
                        required
                        defaultValue="sam@snewroof.com"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 text-sm focus:outline-none focus:border-[#B32D6A] transition-colors placeholder-white/20 text-white"
                      />
                    </div>
                    <div className="text-left">
                      <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-2 ml-1">{t('portal.label_password')}</label>
                      <input 
                        type="password" 
                        required
                        defaultValue="••••••••"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 text-sm focus:outline-none focus:border-[#B32D6A] transition-colors placeholder-white/20 text-white"
                      />
                    </div>
                  </form>
                </div>

                <div className="flex justify-center">
                  <button 
                    onClick={handleLogin}
                    className="px-10 py-4 border-2 border-white bg-transparent text-white font-bold uppercase tracking-[0.2em] text-xs hover:bg-white hover:text-black transition-all duration-300"
                  >
                    {t('portal.btn_initialize')}
                  </button>
                </div>
              </Reveal>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key="portal"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex h-[calc(100vh-160px)] overflow-hidden bg-black"
          >
            {/* Sidebar - Deep Matte Black */}
            <aside className="w-64 border-r border-white/5 bg-black hidden md:flex flex-col">
              <div className="p-8 border-b border-white/5">
                <div className="text-sm font-display tracking-[0.2em] text-white flex items-center">
                  <span className="font-black">NXL</span>
                  <span className="font-light ml-1 opacity-50 uppercase">portal</span>
                </div>
              </div>
              <nav className="flex-grow p-6 space-y-2">
                <div className="flex items-center gap-3 p-3 bg-[#B32D6A]/20 text-[#B32D6A] rounded-lg text-sm font-bold uppercase tracking-wider border border-[#B32D6A]/30">
                  <LayoutDashboard size={18} /> {t('portal.nav_dashboard')}
                </div>
                <div className="flex items-center gap-3 p-3 text-white/30 hover:text-white hover:bg-white/5 rounded-lg text-sm font-medium transition-colors cursor-not-allowed">
                  <BarChart3 size={18} /> {t('portal.nav_performance')}
                </div>
                <div className="flex items-center gap-3 p-3 text-white/30 hover:text-white hover:bg-white/5 rounded-lg text-sm font-medium transition-colors cursor-not-allowed">
                  <Users size={18} /> {t('portal.nav_leads')}
                </div>
                <div className="flex items-center gap-3 p-3 text-white/30 hover:text-white hover:bg-white/5 rounded-lg text-sm font-medium transition-colors cursor-not-allowed">
                  <Zap size={18} /> {t('portal.nav_automations')}
                </div>
              </nav>
              <div className="p-6 border-t border-white/5">
                <button 
                  onClick={() => setIsLoggedIn(false)}
                  className="flex items-center gap-3 p-3 text-white/30 hover:text-red-500 transition-colors text-sm font-medium w-full"
                >
                  <LogOut size={18} /> {t('portal.nav_signout')}
                </button>
              </div>
            </aside>

            {/* Main Content - Deep Matte Black */}
            <main className="flex-grow overflow-y-auto bg-black">
              <header className="h-20 border-b border-white/5 flex items-center justify-between px-8 sticky top-0 bg-black/80 backdrop-blur-md z-10">
                <h2 className="text-sm font-bold uppercase tracking-widest text-white/40">{t('portal.header_title')}</h2>
                <div className="flex items-center gap-6">
                  <Bell size={18} className="text-white/40" />
                  <div className="flex items-center gap-3">
                    <div className="text-right hidden sm:block">
                      <div className="text-xs font-bold text-white">Sam (SNEWROOF)</div>
                      <div className="text-[10px] text-[#B32D6A] uppercase tracking-tighter font-black">{t('portal.user_status')}</div>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-[#B32D6A] flex items-center justify-center font-black text-xs text-white">S</div>
                  </div>
                </div>
              </header>

              <div className="p-8 max-w-6xl mx-auto">
                {/* Welcome Modal */}
                <AnimatePresence>
                  {showWelcome && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9, y: 20 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: 20 }}
                      className="mb-12 p-10 bg-gradient-to-br from-[#30001D] to-[#000000] border border-[#B32D6A]/20 rounded-3xl relative overflow-hidden shadow-2xl shadow-[#B32D6A]/10"
                    >
                      <button 
                        onClick={() => setShowWelcome(false)}
                        className="absolute top-6 right-6 text-white/40 hover:text-white transition-colors"
                      >
                        <X size={20} />
                      </button>
                      <div className="relative z-10">
                        <div className="flex items-center gap-3 mb-6">
                          <Zap className="text-[#B32D6A] w-6 h-6" />
                          <span className="text-[10px] font-black uppercase tracking-[0.4em] text-[#B32D6A]">{t('portal.welcome_badge')}</span>
                        </div>
                        <h3 className="text-4xl font-display font-black tracking-tighter mb-6 uppercase leading-none text-white">
                          {t('portal.welcome_title').split(' ').slice(0, -2).join(' ')} <br/><span className="text-[#B32D6A]">{t('portal.welcome_title').split(' ').slice(-2).join(' ')}</span>
                        </h3>
                        <p className="text-lg text-white/80 leading-relaxed max-w-3xl font-light">
                          {t('portal.welcome_text')}
                        </p>
                      </div>
                      <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-[#B32D6A]/5 rounded-full blur-[100px]"></div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Dashboard Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                  <div className="p-8 bg-white/5 border border-white/10 rounded-2xl">
                    <div className="text-[10px] uppercase tracking-widest text-white/40 mb-4">{t('portal.card_phase_label')}</div>
                    <div className="text-2xl font-bold mb-2 text-white">{t('portal.card_phase_title')}</div>
                    <div className="text-xs text-[#B32D6A] font-mono">{t('portal.card_phase_day')}</div>
                    <div className="mt-6 h-1 bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-[#B32D6A] w-[26%]"></div>
                    </div>
                  </div>
                  <div className="p-8 bg-white/5 border border-white/10 rounded-2xl">
                    <div className="text-[10px] uppercase tracking-widest text-white/40 mb-4">{t('portal.card_status_label')}</div>
                    <div className="text-2xl font-bold mb-2 uppercase tracking-tighter text-white">{t('portal.card_status_title')}</div>
                    <div className="text-xs text-[#B32D6A] font-mono font-bold">{t('portal.card_status_channels')}</div>
                  </div>
                  <div className="p-8 bg-white/5 border border-white/10 rounded-2xl">
                    <div className="text-[10px] uppercase tracking-widest text-white/40 mb-4">{t('portal.card_spend_label')}</div>
                    <div className="text-2xl font-bold mb-2 text-white">$500.00</div>
                    <div className="text-xs text-white/30 font-mono uppercase tracking-widest">{t('portal.card_spend_pending')}</div>
                  </div>
                </div>

                {/* Tactical Advice */}
                <div className="mt-20 pt-20 border-t border-white/5">
                  <h3 className="text-2xl font-display font-bold mb-12 italic opacity-80 text-center text-white">{t('portal.tactical_title')}</h3>
                  <div className="grid md:grid-cols-2 gap-12">
                    <div className="space-y-6">
                      <div className="p-6 bg-white/5 rounded-2xl border border-white/10">
                        <h4 className="text-[10px] font-black uppercase tracking-widest mb-4 text-[#B32D6A]">{t('portal.tactical_law_title')}</h4>
                        <p className="text-white/60 text-sm leading-relaxed">
                          {t('portal.tactical_law_text')}
                        </p>
                      </div>
                      <div className="p-6 bg-white/5 rounded-2xl border border-white/10">
                        <h4 className="text-[10px] font-black uppercase tracking-widest mb-4 text-[#B32D6A]">{t('portal.tactical_sam_title')}</h4>
                        <p className="text-white/60 text-sm leading-relaxed">
                          {t('portal.tactical_sam_text')}
                        </p>
                      </div>
                    </div>
                    <div className="p-8 bg-white/5 border border-dashed border-white/20 rounded-3xl flex flex-col justify-center">
                      <h4 className="text-xl font-display font-black mb-4 uppercase tracking-tighter text-white">{t('portal.tactical_test_title')}</h4>
                      <p className="text-white/60 text-sm leading-relaxed mb-6">
                        {t('portal.tactical_test_text')}
                      </p>
                      <div className="p-4 bg-black rounded-xl border border-white/10 font-mono text-[10px] text-[#B32D6A]">
                        {t('portal.tactical_logic')}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </main>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
    </Layout>
  );
};

export default ClientPortal;
