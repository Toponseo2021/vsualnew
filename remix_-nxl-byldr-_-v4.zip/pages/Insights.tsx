import React from 'react';
import { Calendar, Clock, ArrowRight, Download } from 'lucide-react';
import Button from '../components/Button';
import Layout from '../components/Layout';

const Insights: React.FC = () => {
  const posts = [
    {
      title: "The Future of AI in US Business: 2025 Outlook",
      excerpt: "Why agentic AI workflows are replacing traditional SaaS stacks for SMEs.",
      date: "Oct 12, 2024",
      readTime: "5 min read",
      category: "AI Trends",
      image: "https://picsum.photos/seed/ai/800/400"
    },
    {
      title: "UX Trends Defining the Next Decade",
      excerpt: "Moving beyond flat design: How spatial interfaces and micro-interactions drive conversion.",
      date: "Sep 28, 2024",
      readTime: "4 min read",
      category: "Design",
      image: "https://picsum.photos/seed/ux/800/400"
    },
    {
      title: "Scaling Ad Spend Profitably on TikTok",
      excerpt: "The creative-first approach to lowering CPA while increasing volume.",
      date: "Sep 15, 2024",
      readTime: "6 min read",
      category: "Marketing",
      image: "https://picsum.photos/seed/ads/800/400"
    }
  ];

  return (
    <Layout>
      <div className="bg-white min-h-screen pb-24 pt-32">
        {/* Lead Magnet */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
          <div className="bg-gradient-to-r from-[#B32D6A] to-purple-900 rounded-2xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8 border border-white/10 shadow-2xl">
            <div className="md:w-2/3">
              <span className="inline-block px-3 py-1 bg-white/10 text-white text-xs font-bold rounded-full mb-4">FREE RESOURCE</span>
              <h2 className="text-3xl font-bold text-white mb-4">Is Your Business Ready for AI Automation?</h2>
              <p className="text-pink-100 text-lg">Download our comprehensive checklist to evaluate your data infrastructure and operational readiness.</p>
            </div>
            <div className="md:w-1/3 flex justify-center md:justify-end">
               <Button size="lg" className="flex items-center gap-2 bg-white text-black hover:bg-slate-100 border-none">
                 <Download size={20} /> Download Checklist
               </Button>
            </div>
          </div>
        </div>

        {/* Blog Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-black mb-12 border-l-4 border-[#B32D6A] pl-4">Latest Insights</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {posts.map((post, idx) => (
              <article key={idx} className="bg-slate-50 rounded-xl overflow-hidden border border-slate-100 hover:border-[#B32D6A]/30 transition-colors group cursor-pointer">
                <div className="h-48 overflow-hidden">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-4 text-xs text-slate-500 mb-4">
                    <span className="text-[#B32D6A] font-medium">{post.category}</span>
                    <div className="flex items-center gap-1"><Calendar size={12} /> {post.date}</div>
                    <div className="flex items-center gap-1"><Clock size={12} /> {post.readTime}</div>
                  </div>
                  <h3 className="text-xl font-bold text-black mb-3 group-hover:text-[#B32D6A] transition-colors">{post.title}</h3>
                  <p className="text-slate-600 text-sm mb-6">{post.excerpt}</p>
                  <div className="flex items-center text-[#B32D6A] text-sm font-medium">
                    Read Article <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Insights;