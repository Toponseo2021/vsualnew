import { LucideIcon } from 'lucide-react';

export enum ServiceCategory {
  MARKETING = 'Marketing',
  DEVELOPMENT = 'Development',
  AI = 'AI & Automation',
  DESIGN = 'Design',
}

export interface Service {
  id: string;
  title: string;
  description: string;
  category: ServiceCategory;
  icon: LucideIcon;
  features: string[];
}

export interface CaseStudy {
  id: string;
  client: string;
  title: string;
  industry: string;
  category: ServiceCategory;
  stats: { label: string; value: string }[];
  image: string;
  description: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  category: string;
  readTime: string;
  image: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isError?: boolean;
}